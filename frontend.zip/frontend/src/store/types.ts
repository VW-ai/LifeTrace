/**
 * Store Type Definitions
 *
 * TypeScript types specific to the global state store.
 * Atomic responsibility: store type definitions only.
 */

import type {
  Event,
  TagSummary,
  TagCooccurrence,
  TagTransition,
  TagCluster,
  TagTimeSeries
} from '../api';

// Time Window & Filtering
export interface TimeWindow {
  start: string; // ISO date string
  end: string; // ISO date string
  granularity: 'hour' | 'day' | 'week' | 'month';
}

export interface TagFilter {
  included_tags: string[];
  excluded_tags: string[];
  sources: Array<'google_calendar' | 'notion' | 'manual'>;
  time_window: TimeWindow;
}

// View State
export interface ViewState {
  active_view: 'dashboard' | 'timeline' | 'galaxy' | 'river' | 'calendar' | 'chords' | 'stories';
  is_compare_mode: boolean;
  compare_sets: {
    a: string[]; // tag set A
    b: string[]; // tag set B
  };
  selected_tags: string[];
  hovered_tag: string | null;
  brush_selection: TimeWindow | null;
  sidebar_collapsed: boolean;
  drawer_open: boolean;
}

// Data State
export interface DataState {
  events: Event[];
  tag_summaries: TagSummary[];
  tag_cooccurrences: TagCooccurrence[];
  tag_transitions: TagTransition[];
  tag_clusters: TagCluster[];
  tag_time_series: TagTimeSeries[];
}

// Loading State
export interface LoadingState {
  events: boolean;
  tag_summaries: boolean;
  tag_cooccurrences: boolean;
  tag_transitions: boolean;
  tag_clusters: boolean;
  tag_time_series: boolean;
  health: boolean;
}

// Error State
export interface ErrorState {
  events: string | null;
  tag_summaries: string | null;
  tag_cooccurrences: string | null;
  tag_transitions: string | null;
  tag_clusters: string | null;
  tag_time_series: string | null;
  health: string | null;
  global: string | null;
}

// Performance State
export interface PerformanceState {
  is_large_data_mode: boolean;
  data_size: number;
  render_fps: number;
  last_interaction_time: number;
}

// Story (saved filter state)
export interface Story {
  id: string;
  name: string;
  description?: string;
  created_at: string;
  filter_state: TagFilter;
  view_state: Partial<ViewState>;
  snapshot_url?: string;
}

// Combined Store State
export interface StoreState {
  // Data
  data: DataState;

  // UI State
  filters: TagFilter;
  view: ViewState;

  // Status
  loading: LoadingState;
  errors: ErrorState;
  performance: PerformanceState;

  // Stories
  stories: Story[];
  active_story: string | null;
}

// Store Actions
export interface StoreActions {
  // Data actions
  loadEvents: (forceRefresh?: boolean) => Promise<void>;
  loadTagSummaries: (forceRefresh?: boolean) => Promise<void>;
  loadTagCooccurrences: (forceRefresh?: boolean) => Promise<void>;
  loadTagTransitions: (forceRefresh?: boolean) => Promise<void>;
  loadTagClusters: (forceRefresh?: boolean) => Promise<void>;
  loadTagTimeSeries: (forceRefresh?: boolean) => Promise<void>;
  loadAllData: (forceRefresh?: boolean) => Promise<void>;

  // Filter actions
  setTimeWindow: (window: TimeWindow) => void;
  addTagFilter: (tag: string) => void;
  removeTagFilter: (tag: string) => void;
  toggleTagFilter: (tag: string) => void;
  clearTagFilters: () => void;
  setSourceFilters: (sources: Array<'google_calendar' | 'notion' | 'manual'>) => void;
  setBrushSelection: (selection: TimeWindow | null) => void;

  // View actions
  setActiveView: (view: ViewState['active_view']) => void;
  setCompareMode: (enabled: boolean) => void;
  setCompareSet: (set: 'a' | 'b', tags: string[]) => void;
  addToCompareSet: (set: 'a' | 'b', tag: string) => void;
  removeFromCompareSet: (set: 'a' | 'b', tag: string) => void;
  setSelectedTags: (tags: string[]) => void;
  setHoveredTag: (tag: string | null) => void;
  toggleSidebar: () => void;
  toggleDrawer: () => void;

  // Story actions
  saveStory: (name: string, description?: string) => string;
  loadStory: (storyId: string) => void;
  deleteStory: (storyId: string) => void;

  // Error handling
  clearError: (key: keyof ErrorState) => void;
  clearAllErrors: () => void;

  // Performance
  updatePerformanceMetrics: (metrics: Partial<PerformanceState>) => void;

  // URL sync
  syncFromUrl: (searchParams: URLSearchParams) => void;
  syncToUrl: () => URLSearchParams;
}

// Combined store type
export type Store = StoreState & StoreActions;
/**
 * URL Synchronization Utilities
 *
 * Handles bi-directional synchronization between store state and URL parameters
 * for shareable stories and deep linking. Atomic responsibility: URL operations only.
 */

import type { TagFilter, ViewState, TimeWindow } from './types';

// URL parameter keys
const URL_KEYS = {
  view: 'view',
  tags: 'tags',
  exclude: 'exclude',
  sources: 'sources',
  start: 'start',
  end: 'end',
  granularity: 'g',
  compare: 'compare',
  compareA: 'cmp_a',
  compareB: 'cmp_b',
  story: 'story'
} as const;

// Serialize arrays to comma-separated strings
const serializeArray = (arr: string[]): string => arr.join(',');
const deserializeArray = (str: string): string[] =>
  str ? str.split(',').filter(Boolean) : [];

// Serialize time window
const serializeTimeWindow = (window: TimeWindow): Record<string, string> => ({
  [URL_KEYS.start]: window.start,
  [URL_KEYS.end]: window.end,
  [URL_KEYS.granularity]: window.granularity
});

// Deserialize time window
const deserializeTimeWindow = (params: URLSearchParams): TimeWindow | null => {
  const start = params.get(URL_KEYS.start);
  const end = params.get(URL_KEYS.end);
  const granularity = params.get(URL_KEYS.granularity) as TimeWindow['granularity'];

  if (!start || !end) return null;

  return {
    start,
    end,
    granularity: granularity || 'day'
  };
};

// Serialize filters to URL parameters
export const serializeFiltersToUrl = (filters: TagFilter): URLSearchParams => {
  const params = new URLSearchParams();

  // Tag filters
  if (filters.included_tags.length > 0) {
    params.set(URL_KEYS.tags, serializeArray(filters.included_tags));
  }

  if (filters.excluded_tags.length > 0) {
    params.set(URL_KEYS.exclude, serializeArray(filters.excluded_tags));
  }

  // Source filters (only if not all sources)
  const allSources = ['google_calendar', 'notion', 'manual'] as const;
  if (filters.sources.length > 0 && filters.sources.length < allSources.length) {
    params.set(URL_KEYS.sources, serializeArray(filters.sources));
  }

  // Time window
  const timeParams = serializeTimeWindow(filters.time_window);
  Object.entries(timeParams).forEach(([key, value]) => {
    params.set(key, value);
  });

  return params;
};

// Deserialize filters from URL parameters
export const deserializeFiltersFromUrl = (params: URLSearchParams): Partial<TagFilter> => {
  const filters: Partial<TagFilter> = {};

  // Tag filters
  const includedTags = params.get(URL_KEYS.tags);
  if (includedTags) {
    filters.included_tags = deserializeArray(includedTags);
  }

  const excludedTags = params.get(URL_KEYS.exclude);
  if (excludedTags) {
    filters.excluded_tags = deserializeArray(excludedTags);
  }

  // Source filters
  const sources = params.get(URL_KEYS.sources);
  if (sources) {
    filters.sources = deserializeArray(sources) as TagFilter['sources'];
  }

  // Time window
  const timeWindow = deserializeTimeWindow(params);
  if (timeWindow) {
    filters.time_window = timeWindow;
  }

  return filters;
};

// Serialize view state to URL parameters
export const serializeViewToUrl = (view: ViewState): URLSearchParams => {
  const params = new URLSearchParams();

  // Active view
  if (view.active_view !== 'dashboard') { // default
    params.set(URL_KEYS.view, view.active_view);
  }

  // Compare mode
  if (view.is_compare_mode) {
    params.set(URL_KEYS.compare, 'true');

    if (view.compare_sets.a.length > 0) {
      params.set(URL_KEYS.compareA, serializeArray(view.compare_sets.a));
    }

    if (view.compare_sets.b.length > 0) {
      params.set(URL_KEYS.compareB, serializeArray(view.compare_sets.b));
    }
  }

  return params;
};

// Deserialize view state from URL parameters
export const deserializeViewFromUrl = (params: URLSearchParams): Partial<ViewState> => {
  const view: Partial<ViewState> = {};

  // Active view
  const activeView = params.get(URL_KEYS.view) as ViewState['active_view'];
  if (activeView) {
    view.active_view = activeView;
  }

  // Compare mode
  const isCompareMode = params.get(URL_KEYS.compare) === 'true';
  if (isCompareMode) {
    view.is_compare_mode = true;

    const compareA = params.get(URL_KEYS.compareA);
    const compareB = params.get(URL_KEYS.compareB);

    view.compare_sets = {
      a: compareA ? deserializeArray(compareA) : [],
      b: compareB ? deserializeArray(compareB) : []
    };
  }

  return view;
};

// Combine all state into URL parameters
export const serializeStateToUrl = (
  filters: TagFilter,
  view: ViewState,
  activeStory?: string
): URLSearchParams => {
  const params = new URLSearchParams();

  // Merge filter and view parameters
  const filterParams = serializeFiltersToUrl(filters);
  const viewParams = serializeViewToUrl(view);

  filterParams.forEach((value, key) => params.set(key, value));
  viewParams.forEach((value, key) => params.set(key, value));

  // Story ID
  if (activeStory) {
    params.set(URL_KEYS.story, activeStory);
  }

  return params;
};

// Deserialize all state from URL parameters
export const deserializeStateFromUrl = (params: URLSearchParams) => {
  const filters = deserializeFiltersFromUrl(params);
  const view = deserializeViewFromUrl(params);
  const story = params.get(URL_KEYS.story);

  return {
    filters,
    view,
    story
  };
};

// Debounced URL update utility
export const createDebouncedUrlSync = (
  updateUrl: (params: URLSearchParams) => void,
  delay = 300
) => {
  let timeoutId: number | null = null;

  return (params: URLSearchParams) => {
    if (timeoutId) {
      clearTimeout(timeoutId);
    }

    timeoutId = setTimeout(() => {
      updateUrl(params);
      timeoutId = null;
    }, delay);
  };
};

// URL validation utilities
export const isValidDateString = (date: string): boolean => {
  return /^\d{4}-\d{2}-\d{2}$/.test(date) && !isNaN(Date.parse(date));
};

export const isValidView = (view: string): view is ViewState['active_view'] => {
  const validViews = ['dashboard', 'timeline', 'galaxy', 'river', 'calendar', 'chords', 'stories'];
  return validViews.includes(view);
};

export const isValidGranularity = (granularity: string): granularity is TimeWindow['granularity'] => {
  const validGranularities = ['hour', 'day', 'week', 'month'];
  return validGranularities.includes(granularity);
};

export const isValidSource = (source: string): source is 'google_calendar' | 'notion' | 'manual' => {
  const validSources = ['google_calendar', 'notion', 'manual'];
  return validSources.includes(source);
};
/**
 * Global State Store - Main Implementation
 *
 * Zustand store with URL synchronization for the tag-driven visualization interface.
 * Atomic responsibility: state management and coordination only.
 */

import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import { apiClient } from '../api';
import type { Store, TagFilter, ViewState, TimeWindow, Story } from './types';
import {
  serializeStateToUrl,
  deserializeStateFromUrl,
  createDebouncedUrlSync
} from './url-sync';

// Default state values
const createDefaultTimeWindow = (): TimeWindow => {
  const end = new Date().toISOString().split('T')[0]; // Today
  const start = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]; // 30 days ago
  return {
    start,
    end,
    granularity: 'day'
  };
};

const createDefaultFilters = (): TagFilter => ({
  included_tags: [],
  excluded_tags: [],
  sources: ['google_calendar', 'notion', 'manual'],
  time_window: createDefaultTimeWindow()
});

const createDefaultViewState = (): ViewState => ({
  active_view: 'dashboard',
  is_compare_mode: false,
  compare_sets: {
    a: [],
    b: []
  },
  selected_tags: [],
  hovered_tag: null,
  brush_selection: null,
  sidebar_collapsed: false,
  drawer_open: false
});

// Create the store
export const useStore = create<Store>()(
  subscribeWithSelector((set, get) => ({
    // Initial state
    data: {
      events: [],
      tag_summaries: [],
      tag_cooccurrences: [],
      tag_transitions: [],
      tag_clusters: [],
      tag_time_series: []
    },

    filters: createDefaultFilters(),
    view: createDefaultViewState(),

    loading: {
      events: false,
      tag_summaries: false,
      tag_cooccurrences: false,
      tag_transitions: false,
      tag_clusters: false,
      tag_time_series: false,
      health: false
    },

    errors: {
      events: null,
      tag_summaries: null,
      tag_cooccurrences: null,
      tag_transitions: null,
      tag_clusters: null,
      tag_time_series: null,
      health: null,
      global: null
    },

    performance: {
      is_large_data_mode: false,
      data_size: 0,
      render_fps: 60,
      last_interaction_time: Date.now()
    },

    stories: [],
    active_story: null,

    // Data loading actions
    loadEvents: async (forceRefresh = false) => {
      const { filters } = get();
      set((state) => ({ loading: { ...state.loading, events: true } }));

      try {
        const response = await apiClient.getEvents(
          {
            start_date: filters.time_window.start,
            end_date: filters.time_window.end,
            tags: filters.included_tags.length > 0 ? filters.included_tags : undefined,
            exclude_tags: filters.excluded_tags.length > 0 ? filters.excluded_tags : undefined,
            sources: filters.sources
          },
          { forceRefresh }
        );

        set((state) => ({
          data: { ...state.data, events: response.data },
          loading: { ...state.loading, events: false },
          errors: { ...state.errors, events: null },
          performance: {
            ...state.performance,
            data_size: response.data.length,
            is_large_data_mode: response.data.length > 1000
          }
        }));
      } catch (error) {
        set((state) => ({
          loading: { ...state.loading, events: false },
          errors: { ...state.errors, events: error instanceof Error ? error.message : 'Failed to load events' }
        }));
      }
    },

    loadTagSummaries: async (forceRefresh = false) => {
      const { filters } = get();
      set((state) => ({ loading: { ...state.loading, tag_summaries: true } }));

      try {
        const response = await apiClient.getTagSummary(
          {
            start_date: filters.time_window.start,
            end_date: filters.time_window.end,
            sources: filters.sources
          },
          { forceRefresh }
        );

        set((state) => ({
          data: { ...state.data, tag_summaries: response.data },
          loading: { ...state.loading, tag_summaries: false },
          errors: { ...state.errors, tag_summaries: null }
        }));
      } catch (error) {
        set((state) => ({
          loading: { ...state.loading, tag_summaries: false },
          errors: { ...state.errors, tag_summaries: error instanceof Error ? error.message : 'Failed to load tag summaries' }
        }));
      }
    },

    loadTagCooccurrences: async (forceRefresh = false) => {
      const { filters } = get();
      set((state) => ({ loading: { ...state.loading, tag_cooccurrences: true } }));

      try {
        const response = await apiClient.getTagCooccurrence(
          {
            start_date: filters.time_window.start,
            end_date: filters.time_window.end,
            tags: filters.included_tags.length > 0 ? filters.included_tags : undefined,
            sources: filters.sources,
            threshold: 2 // Minimum co-occurrence count
          },
          { forceRefresh }
        );

        set((state) => ({
          data: { ...state.data, tag_cooccurrences: response.data },
          loading: { ...state.loading, tag_cooccurrences: false },
          errors: { ...state.errors, tag_cooccurrences: null }
        }));
      } catch (error) {
        set((state) => ({
          loading: { ...state.loading, tag_cooccurrences: false },
          errors: { ...state.errors, tag_cooccurrences: error instanceof Error ? error.message : 'Failed to load tag co-occurrences' }
        }));
      }
    },

    loadTagTransitions: async (forceRefresh = false) => {
      const { filters } = get();
      set((state) => ({ loading: { ...state.loading, tag_transitions: true } }));

      try {
        const response = await apiClient.getTagTransitions(
          {
            start_date: filters.time_window.start,
            end_date: filters.time_window.end,
            sources: filters.sources
          },
          { forceRefresh }
        );

        set((state) => ({
          data: { ...state.data, tag_transitions: response.data },
          loading: { ...state.loading, tag_transitions: false },
          errors: { ...state.errors, tag_transitions: null }
        }));
      } catch (error) {
        set((state) => ({
          loading: { ...state.loading, tag_transitions: false },
          errors: { ...state.errors, tag_transitions: error instanceof Error ? error.message : 'Failed to load tag transitions' }
        }));
      }
    },

    loadTagClusters: async (forceRefresh = false) => {
      const { filters } = get();
      set((state) => ({ loading: { ...state.loading, tag_clusters: true } }));

      try {
        const response = await apiClient.getTagClusters(
          {
            start_date: filters.time_window.start,
            end_date: filters.time_window.end,
            sources: filters.sources
          },
          { forceRefresh }
        );

        set((state) => ({
          data: { ...state.data, tag_clusters: response.data },
          loading: { ...state.loading, tag_clusters: false },
          errors: { ...state.errors, tag_clusters: null }
        }));
      } catch (error) {
        set((state) => ({
          loading: { ...state.loading, tag_clusters: false },
          errors: { ...state.errors, tag_clusters: error instanceof Error ? error.message : 'Failed to load tag clusters' }
        }));
      }
    },

    loadTagTimeSeries: async (forceRefresh = false) => {
      const { filters } = get();
      set((state) => ({ loading: { ...state.loading, tag_time_series: true } }));

      try {
        const response = await apiClient.getTagTimeSeries(
          {
            start_date: filters.time_window.start,
            end_date: filters.time_window.end,
            granularity: filters.time_window.granularity,
            tags: filters.included_tags.length > 0 ? filters.included_tags : undefined,
            sources: filters.sources
          },
          { forceRefresh }
        );

        set((state) => ({
          data: { ...state.data, tag_time_series: response.data },
          loading: { ...state.loading, tag_time_series: false },
          errors: { ...state.errors, tag_time_series: null }
        }));
      } catch (error) {
        set((state) => ({
          loading: { ...state.loading, tag_time_series: false },
          errors: { ...state.errors, tag_time_series: error instanceof Error ? error.message : 'Failed to load tag time series' }
        }));
      }
    },

    loadAllData: async (forceRefresh = false) => {
      const actions = get();
      await Promise.all([
        actions.loadEvents(forceRefresh),
        actions.loadTagSummaries(forceRefresh),
        actions.loadTagCooccurrences(forceRefresh),
        actions.loadTagTransitions(forceRefresh),
        actions.loadTagClusters(forceRefresh),
        actions.loadTagTimeSeries(forceRefresh)
      ]);
    },

    // Filter actions
    setTimeWindow: (window) => {
      set((state) => ({
        filters: { ...state.filters, time_window: window }
      }));
      // Reload data with new time window
      get().loadAllData();
    },

    addTagFilter: (tag) => {
      set((state) => ({
        filters: {
          ...state.filters,
          included_tags: [...state.filters.included_tags.filter(t => t !== tag), tag]
        }
      }));
      get().loadEvents(); // Reload filtered events
    },

    removeTagFilter: (tag) => {
      set((state) => ({
        filters: {
          ...state.filters,
          included_tags: state.filters.included_tags.filter(t => t !== tag)
        }
      }));
      get().loadEvents();
    },

    toggleTagFilter: (tag) => {
      const { filters } = get();
      if (filters.included_tags.includes(tag)) {
        get().removeTagFilter(tag);
      } else {
        get().addTagFilter(tag);
      }
    },

    clearTagFilters: () => {
      set((state) => ({
        filters: {
          ...state.filters,
          included_tags: [],
          excluded_tags: []
        }
      }));
      get().loadEvents();
    },

    setSourceFilters: (sources) => {
      set((state) => ({
        filters: { ...state.filters, sources }
      }));
      get().loadAllData();
    },

    setBrushSelection: (selection) => {
      set((state) => ({
        view: { ...state.view, brush_selection: selection }
      }));
    },

    // View actions
    setActiveView: (view) => {
      set((state) => ({
        view: { ...state.view, active_view: view }
      }));
    },

    setCompareMode: (enabled) => {
      set((state) => ({
        view: { ...state.view, is_compare_mode: enabled }
      }));
    },

    setCompareSet: (setKey, tags) => {
      set((state) => ({
        view: {
          ...state.view,
          compare_sets: {
            ...state.view.compare_sets,
            [setKey]: tags
          }
        }
      }));
    },

    addToCompareSet: (setKey, tag) => {
      const { view } = get();
      const currentSet = view.compare_sets[setKey];
      if (!currentSet.includes(tag)) {
        get().setCompareSet(setKey, [...currentSet, tag]);
      }
    },

    removeFromCompareSet: (setKey, tag) => {
      const { view } = get();
      const currentSet = view.compare_sets[setKey];
      get().setCompareSet(setKey, currentSet.filter(t => t !== tag));
    },

    setSelectedTags: (tags) => {
      set((state) => ({
        view: { ...state.view, selected_tags: tags }
      }));
    },

    setHoveredTag: (tag) => {
      set((state) => ({
        view: { ...state.view, hovered_tag: tag },
        performance: { ...state.performance, last_interaction_time: Date.now() }
      }));
    },

    toggleSidebar: () => {
      set((state) => ({
        view: { ...state.view, sidebar_collapsed: !state.view.sidebar_collapsed }
      }));
    },

    toggleDrawer: () => {
      set((state) => ({
        view: { ...state.view, drawer_open: !state.view.drawer_open }
      }));
    },

    // Story actions
    saveStory: (name, description) => {
      const { filters, view } = get();
      const story: Story = {
        id: `story-${Date.now()}`,
        name,
        description,
        created_at: new Date().toISOString(),
        filter_state: filters,
        view_state: {
          active_view: view.active_view,
          is_compare_mode: view.is_compare_mode,
          compare_sets: view.compare_sets
        }
      };

      set((state) => ({
        stories: [...state.stories, story],
        active_story: story.id
      }));

      return story.id;
    },

    loadStory: (storyId) => {
      const { stories } = get();
      const story = stories.find(s => s.id === storyId);
      if (story) {
        set((state) => ({
          filters: story.filter_state,
          view: { ...state.view, ...story.view_state },
          active_story: storyId
        }));
        get().loadAllData();
      }
    },

    deleteStory: (storyId) => {
      set((state) => ({
        stories: state.stories.filter(s => s.id !== storyId),
        active_story: state.active_story === storyId ? null : state.active_story
      }));
    },

    // Error handling
    clearError: (key) => {
      set((state) => ({
        errors: { ...state.errors, [key]: null }
      }));
    },

    clearAllErrors: () => {
      set((state) => ({
        errors: {
          events: null,
          tag_summaries: null,
          tag_cooccurrences: null,
          tag_transitions: null,
          tag_clusters: null,
          tag_time_series: null,
          health: null,
          global: null
        }
      }));
    },

    // Performance
    updatePerformanceMetrics: (metrics) => {
      set((state) => ({
        performance: { ...state.performance, ...metrics }
      }));
    },

    // URL sync
    syncFromUrl: (searchParams) => {
      const { filters, view, story } = deserializeStateFromUrl(searchParams);

      set((state) => ({
        filters: { ...state.filters, ...filters },
        view: { ...state.view, ...view },
        active_story: story || null
      }));

      // Load story if specified
      if (story) {
        get().loadStory(story);
      } else {
        get().loadAllData();
      }
    },

    syncToUrl: () => {
      const { filters, view, active_story } = get();
      return serializeStateToUrl(filters, view, active_story || undefined);
    }
  }))
);

// URL synchronization setup
let urlSyncInitialized = false;

export const initializeUrlSync = () => {
  if (urlSyncInitialized || typeof window === 'undefined') return;

  const debouncedUrlUpdate = createDebouncedUrlSync((params) => {
    const url = new URL(window.location.href);
    url.search = params.toString();
    window.history.replaceState(null, '', url.toString());
  });

  // Subscribe to store changes and update URL
  useStore.subscribe(
    (state) => ({ filters: state.filters, view: state.view, active_story: state.active_story }),
    ({ filters, view, active_story }) => {
      const params = serializeStateToUrl(filters, view, active_story || undefined);
      debouncedUrlUpdate(params);
    },
    { equalityFn: (a, b) => JSON.stringify(a) === JSON.stringify(b) }
  );

  // Initialize from URL on page load
  const searchParams = new URLSearchParams(window.location.search);
  useStore.getState().syncFromUrl(searchParams);

  urlSyncInitialized = true;
};

// Export selectors for computed values
export const useFilteredEvents = () =>
  useStore((state) => {
    let events = state.data.events;

    // Apply brush selection if active
    if (state.view.brush_selection) {
      const start = new Date(state.view.brush_selection.start);
      const end = new Date(state.view.brush_selection.end);
      events = events.filter(event => {
        const eventDate = new Date(event.date);
        return eventDate >= start && eventDate <= end;
      });
    }

    return events;
  });

export const useTagFrequencies = () =>
  useStore((state) => {
    const events = state.data.events;
    const frequencies: Record<string, number> = {};

    events.forEach(event => {
      event.selected_tags.forEach(tag => {
        frequencies[tag] = (frequencies[tag] || 0) + 1;
      });
    });

    return Object.entries(frequencies)
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count);
  });

export const useIsLoading = () =>
  useStore((state) => Object.values(state.loading).some(Boolean));

export const useHasErrors = () =>
  useStore((state) => Object.values(state.errors).some(Boolean));
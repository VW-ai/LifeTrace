# Global State Store Module

## Purpose
This module provides centralized state management using Zustand for the tag-driven visualization interface. It handles all application state including filters, view configuration, data loading, and URL synchronization for shareable stories.

## Core Logic
- **State Management**: Centralized store for all UI and data state
- **URL Synchronization**: Bi-directional sync between store state and URL parameters
- **Data Fetching**: Integration with API client for data loading and caching
- **Filter Management**: Complex cross-filtering logic across all views

## File Structure
```
store/
├── store_META.md           # This documentation
├── index.ts                # Main store implementation with Zustand
├── url-sync.ts             # URL synchronization utilities
├── data-slice.ts           # Data loading and caching slice
├── filter-slice.ts         # Filter state management slice
├── view-slice.ts           # View state management slice
└── types.ts                # Store-specific type definitions
```

## Key Components
1. **MainStore**: Combined Zustand store with all slices
2. **UrlSync**: Hook for URL parameter synchronization
3. **DataSlice**: Manages API data loading and caching states
4. **FilterSlice**: Handles tag filtering, time windows, and cross-filtering
5. **ViewSlice**: Manages current view, compare mode, and UI state

## State Structure
- `data`: All fetched data (events, tags, aggregations)
- `filters`: Active filters (tags, time window, sources)
- `view`: Current view configuration and UI state
- `loading`: Loading states for different data types
- `errors`: Error states and error handling

## Integration
- Used by all components for state access
- Automatically syncs with URL for shareable links
- Integrates with API client for data fetching
- Provides computed selectors for derived data

## Performance Considerations
- Selective subscriptions to avoid unnecessary re-renders
- Memoized selectors for expensive computations
- Debounced URL updates to prevent excessive history entries
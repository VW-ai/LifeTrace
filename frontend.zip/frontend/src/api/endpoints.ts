/**
 * API Endpoint Definitions
 *
 * Centralized endpoint URLs and parameter building utilities.
 * Atomic responsibility: URL construction and parameter serialization only.
 */

// Base configuration
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';
const API_VERSION = 'v1';

export const BASE_URL = `${API_BASE_URL}/api/${API_VERSION}`;

// Endpoint definitions following FRONTEND_UPDATE_PLAN.md
export const endpoints = {
  // Health check
  health: '/health',

  // Existing endpoints (confirmed available)
  activities: {
    raw: '/activities/raw',
    processed: '/activities/processed'
  },

  insights: {
    overview: '/insights/overview',
    timeDistribution: '/insights/time-distribution'
  },

  tags: {
    list: '/tags'
  },

  // Future aggregate endpoints (to be implemented as needed)
  tagAggregates: {
    summary: '/tags/summary',
    cooccurrence: '/tags/cooccurrence',
    transitions: '/tags/transitions',
    clusters: '/tags/clusters',
    timeSeries: '/tags/time-series'
  }
} as const;

// Query parameter types
export interface PaginationParams {
  limit?: number;
  offset?: number;
}

export interface TimeRangeParams {
  start_date?: string; // YYYY-MM-DD
  end_date?: string; // YYYY-MM-DD
}

export interface TagFilterParams {
  tags?: string[]; // Include only these tags
  exclude_tags?: string[]; // Exclude these tags
  sources?: Array<'google_calendar' | 'notion' | 'manual'>;
}

export interface AggregationParams {
  granularity?: 'hour' | 'day' | 'week' | 'month';
  mode?: 'absolute' | 'normalized' | 'share';
  threshold?: number; // For co-occurrence filtering
}

// Combined parameter interfaces
export interface EventQueryParams extends PaginationParams, TimeRangeParams, TagFilterParams {}

export interface TagAggregateParams extends TimeRangeParams, TagFilterParams, AggregationParams {}

// URL building utilities
export class EndpointBuilder {
  private baseUrl: string;

  constructor(baseUrl: string = BASE_URL) {
    this.baseUrl = baseUrl;
  }

  buildUrl(endpoint: string, params: Record<string, any> = {}): string {
    const url = new URL(endpoint, this.baseUrl);

    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        if (Array.isArray(value)) {
          // Handle array parameters (e.g., tags, sources)
          value.forEach((item) => {
            url.searchParams.append(key, String(item));
          });
        } else {
          url.searchParams.set(key, String(value));
        }
      }
    });

    return url.toString();
  }

  // Convenience methods for common endpoints
  getEvents(params: EventQueryParams = {}): string {
    return this.buildUrl(endpoints.activities.processed, params);
  }

  getRawEvents(params: EventQueryParams = {}): string {
    return this.buildUrl(endpoints.activities.raw, params);
  }

  getTags(params: Partial<TagFilterParams> = {}): string {
    return this.buildUrl(endpoints.tags.list, params);
  }

  getTagSummary(params: TagAggregateParams = {}): string {
    return this.buildUrl(endpoints.tagAggregates.summary, params);
  }

  getTagCooccurrence(params: TagAggregateParams = {}): string {
    return this.buildUrl(endpoints.tagAggregates.cooccurrence, params);
  }

  getTagTransitions(params: TagAggregateParams = {}): string {
    return this.buildUrl(endpoints.tagAggregates.transitions, params);
  }

  getTagClusters(params: TagAggregateParams = {}): string {
    return this.buildUrl(endpoints.tagAggregates.clusters, params);
  }

  getTagTimeSeries(params: TagAggregateParams = {}): string {
    return this.buildUrl(endpoints.tagAggregates.timeSeries, params);
  }

  getHealth(): string {
    return this.buildUrl(endpoints.health);
  }
}

// Export default instance
export const endpointBuilder = new EndpointBuilder();

// Helper function to serialize parameters for cache keys
export const serializeParams = (params: Record<string, any>): string => {
  const sorted = Object.keys(params)
    .sort()
    .reduce((acc, key) => {
      const value = params[key];
      if (value !== undefined && value !== null) {
        acc[key] = Array.isArray(value) ? value.sort() : value;
      }
      return acc;
    }, {} as Record<string, any>);

  return JSON.stringify(sorted);
};
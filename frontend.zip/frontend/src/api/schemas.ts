/**
 * API Response Schemas - Zod Validation
 *
 * Runtime validation schemas for all API responses to ensure type safety
 * and graceful error handling. Follows atomic principle with single responsibility.
 */

import { z } from 'zod';

// Base Event Schema
export const EventSchema = z.object({
  id: z.string(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), // YYYY-MM-DD
  time: z.string().regex(/^\d{2}:\d{2}$/), // HH:MM
  source: z.enum(['google_calendar', 'notion', 'manual']),
  summary: z.string(),
  details: z.string(),
  selected_tags: z.array(z.string()),
  duration_minutes: z.number().optional(),
  processed_at: z.string().optional()
});

// Tag Summary Schema
export const TagSummarySchema = z.object({
  tag: z.string(),
  count: z.number(),
  total_minutes: z.number(),
  color: z.string(),
  first_seen: z.string(),
  last_seen: z.string()
});

// Tag Co-occurrence Schema
export const TagCooccurrenceSchema = z.object({
  tag_a: z.string(),
  tag_b: z.string(),
  count: z.number(),
  jaccard_similarity: z.number().min(0).max(1),
  strength: z.number().min(0).max(1)
});

// Tag Transition Schema
export const TagTransitionSchema = z.object({
  from_tag: z.string(),
  to_tag: z.string(),
  count: z.number(),
  avg_time_between_minutes: z.number(),
  direction: z.enum(['forward', 'backward'])
});

// Tag Cluster Schema
export const TagClusterSchema = z.object({
  cluster_id: z.string(),
  tags: z.array(z.string()),
  coherence_score: z.number().min(0).max(1),
  representative_tag: z.string()
});

// Tag Time Series Schema
export const TagTimeSeriesSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  hour: z.number().min(0).max(23).optional(),
  tag: z.string(),
  count: z.number(),
  total_minutes: z.number(),
  normalized_count: z.number().min(0).max(1),
  share_of_day: z.number().min(0).max(1)
});

// API Response Wrapper Schema
export const ApiResponseSchema = <T extends z.ZodType>(dataSchema: T) =>
  z.object({
    data: dataSchema,
    meta: z
      .object({
        total_count: z.number().optional(),
        page: z.number().optional(),
        limit: z.number().optional(),
        cache_key: z.string().optional()
      })
      .optional(),
    error: z.string().optional()
  });

// Composed Response Schemas
export const EventsResponseSchema = ApiResponseSchema(z.array(EventSchema));
export const TagSummaryResponseSchema = ApiResponseSchema(z.array(TagSummarySchema));
export const TagCooccurrenceResponseSchema = ApiResponseSchema(z.array(TagCooccurrenceSchema));
export const TagTransitionsResponseSchema = ApiResponseSchema(z.array(TagTransitionSchema));
export const TagClustersResponseSchema = ApiResponseSchema(z.array(TagClusterSchema));
export const TagTimeSeriesResponseSchema = ApiResponseSchema(z.array(TagTimeSeriesSchema));

// Health Check Schema
export const HealthResponseSchema = z.object({
  status: z.enum(['healthy', 'degraded', 'unhealthy']),
  timestamp: z.string(),
  services: z.record(z.string(), z.boolean()).optional()
});

// Export inferred types
export type Event = z.infer<typeof EventSchema>;
export type TagSummary = z.infer<typeof TagSummarySchema>;
export type TagCooccurrence = z.infer<typeof TagCooccurrenceSchema>;
export type TagTransition = z.infer<typeof TagTransitionSchema>;
export type TagCluster = z.infer<typeof TagClusterSchema>;
export type TagTimeSeries = z.infer<typeof TagTimeSeriesSchema>;

export type EventsResponse = z.infer<typeof EventsResponseSchema>;
export type TagSummaryResponse = z.infer<typeof TagSummaryResponseSchema>;
export type TagCooccurrenceResponse = z.infer<typeof TagCooccurrenceResponseSchema>;
export type TagTransitionsResponse = z.infer<typeof TagTransitionsResponseSchema>;
export type TagClustersResponse = z.infer<typeof TagClustersResponseSchema>;
export type TagTimeSeriesResponse = z.infer<typeof TagTimeSeriesResponseSchema>;

export type HealthResponse = z.infer<typeof HealthResponseSchema>;
# API Client Module

## Purpose
This module provides a type-safe, schema-validated API client for consuming the FastAPI backend following the FRONTEND_UPDATE_PLAN.md backend-first approach. It handles all communication with existing endpoints and provides hooks for future aggregation endpoints.

## Core Logic
- **Schema Guards**: Validates all API responses using Zod schemas
- **Error Handling**: Provides consistent error handling and retry logic
- **Caching**: Implements IndexedDB cache with stale-while-revalidate strategy
- **Type Safety**: Full TypeScript support for all endpoint types

## File Structure
```
api/
├── client_META.md          # This documentation
├── client.ts               # Main API client implementation
├── schemas.ts              # Zod validation schemas
├── cache.ts                # IndexedDB caching layer
├── endpoints.ts            # Endpoint definitions and utilities
└── types.ts                # API-specific type definitions
```

## Key Components
1. **ApiClient**: Main client class with methods for all endpoints
2. **SchemaValidator**: Runtime validation using Zod
3. **CacheManager**: IndexedDB operations with TTL support
4. **EndpointBuilder**: Utility for constructing API URLs with parameters

## Integration
- Used by Zustand store for data fetching
- Provides React hooks for common operations
- Supports URL parameter serialization for filters

## Error Handling Strategy
- Network errors: Automatic retry with exponential backoff
- Validation errors: Clear error messages with fallback data
- Cache misses: Graceful degradation with loading states
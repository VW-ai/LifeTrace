/**
 * API Client - Main Implementation
 *
 * Type-safe API client with schema validation, caching, and error handling.
 * Atomic responsibility: API communication and response processing only.
 */

import {
  EventsResponseSchema,
  TagSummaryResponseSchema,
  TagCooccurrenceResponseSchema,
  TagTransitionsResponseSchema,
  TagClustersResponseSchema,
  TagTimeSeriesResponseSchema,
  HealthResponseSchema,
  type EventsResponse,
  type TagSummaryResponse,
  type TagCooccurrenceResponse,
  type TagTransitionsResponse,
  type TagClustersResponse,
  type TagTimeSeriesResponse,
  type HealthResponse
} from './schemas';

import { cacheManager, generateCacheKey } from './cache';
import {
  endpointBuilder,
  type EventQueryParams,
  type TagAggregateParams
} from './endpoints';

// Client configuration
interface ClientConfig {
  baseUrl?: string;
  timeout?: number;
  retryAttempts?: number;
  cacheEnabled?: boolean;
}

// Error types
export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public endpoint: string
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export class ValidationError extends Error {
  constructor(message: string, public data: unknown) {
    super(message);
    this.name = 'ValidationError';
  }
}

// Request options
interface RequestOptions {
  useCache?: boolean;
  cacheTtl?: number; // milliseconds
  forceRefresh?: boolean;
}

export class ApiClient {
  private config: Required<ClientConfig>;

  constructor(config: ClientConfig = {}) {
    this.config = {
      baseUrl: 'http://localhost:8000/api/v1',
      timeout: 10000,
      retryAttempts: 3,
      cacheEnabled: true,
      ...config
    };
  }

  private async fetchWithRetry(
    url: string,
    options: RequestInit = {},
    attempts = this.config.retryAttempts
  ): Promise<Response> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers
        }
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new ApiError(response.status, response.statusText, url);
      }

      return response;
    } catch (error) {
      if (attempts > 1 && !(error instanceof ApiError && error.status < 500)) {
        // Retry for network errors and 5xx status codes
        await new Promise(resolve => setTimeout(resolve, 1000));
        return this.fetchWithRetry(url, options, attempts - 1);
      }
      throw error;
    }
  }

  private async fetchAndValidate<T>(
    url: string,
    schema: any,
    options: RequestOptions = {}
  ): Promise<T> {
    const cacheKey = generateCacheKey(url);

    // Check cache first if enabled
    if (this.config.cacheEnabled && options.useCache !== false && !options.forceRefresh) {
      const cached = await cacheManager.get<T>(cacheKey);
      if (cached) {
        // Check if stale and trigger background refresh
        const isStale = await cacheManager.isStale(cacheKey, 60 * 1000); // 1 minute stale time
        if (isStale) {
          // Stale-while-revalidate: return cached data but fetch fresh in background
          this.fetchAndValidate(url, schema, { ...options, useCache: false }).then(fresh => {
            cacheManager.set(cacheKey, fresh, { ttl: options.cacheTtl });
          });
        }
        return cached.data;
      }
    }

    // Fetch fresh data
    const response = await this.fetchWithRetry(url);
    const data = await response.json();

    // Validate with schema
    const validationResult = schema.safeParse(data);
    if (!validationResult.success) {
      throw new ValidationError(
        `Response validation failed for ${url}: ${validationResult.error.message}`,
        data
      );
    }

    const validatedData = validationResult.data as T;

    // Cache if enabled
    if (this.config.cacheEnabled && options.useCache !== false) {
      await cacheManager.set(cacheKey, validatedData, { ttl: options.cacheTtl });
    }

    return validatedData;
  }

  // Health check
  async getHealth(): Promise<HealthResponse> {
    const url = endpointBuilder.getHealth();
    return this.fetchAndValidate(url, HealthResponseSchema, { useCache: false });
  }

  // Event endpoints
  async getEvents(params: EventQueryParams = {}, options: RequestOptions = {}): Promise<EventsResponse> {
    const url = endpointBuilder.getEvents(params);
    return this.fetchAndValidate(url, EventsResponseSchema, { cacheTtl: 2 * 60 * 1000, ...options });
  }

  async getRawEvents(params: EventQueryParams = {}, options: RequestOptions = {}): Promise<EventsResponse> {
    const url = endpointBuilder.getRawEvents(params);
    return this.fetchAndValidate(url, EventsResponseSchema, { cacheTtl: 5 * 60 * 1000, ...options });
  }

  // Tag aggregate endpoints (may not exist yet - will gracefully fail)
  async getTagSummary(params: TagAggregateParams = {}, options: RequestOptions = {}): Promise<TagSummaryResponse> {
    const url = endpointBuilder.getTagSummary(params);
    try {
      return await this.fetchAndValidate(url, TagSummaryResponseSchema, { cacheTtl: 5 * 60 * 1000, ...options });
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) {
        // Endpoint not implemented yet - return empty response
        return { data: [] };
      }
      throw error;
    }
  }

  async getTagCooccurrence(params: TagAggregateParams = {}, options: RequestOptions = {}): Promise<TagCooccurrenceResponse> {
    const url = endpointBuilder.getTagCooccurrence(params);
    try {
      return await this.fetchAndValidate(url, TagCooccurrenceResponseSchema, { cacheTtl: 5 * 60 * 1000, ...options });
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) {
        return { data: [] };
      }
      throw error;
    }
  }

  async getTagTransitions(params: TagAggregateParams = {}, options: RequestOptions = {}): Promise<TagTransitionsResponse> {
    const url = endpointBuilder.getTagTransitions(params);
    try {
      return await this.fetchAndValidate(url, TagTransitionsResponseSchema, { cacheTtl: 5 * 60 * 1000, ...options });
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) {
        return { data: [] };
      }
      throw error;
    }
  }

  async getTagClusters(params: TagAggregateParams = {}, options: RequestOptions = {}): Promise<TagClustersResponse> {
    const url = endpointBuilder.getTagClusters(params);
    try {
      return await this.fetchAndValidate(url, TagClustersResponseSchema, { cacheTtl: 10 * 60 * 1000, ...options });
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) {
        return { data: [] };
      }
      throw error;
    }
  }

  async getTagTimeSeries(params: TagAggregateParams = {}, options: RequestOptions = {}): Promise<TagTimeSeriesResponse> {
    const url = endpointBuilder.getTagTimeSeries(params);
    try {
      return await this.fetchAndValidate(url, TagTimeSeriesResponseSchema, { cacheTtl: 2 * 60 * 1000, ...options });
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) {
        return { data: [] };
      }
      throw error;
    }
  }

  // Cache management
  async clearCache(): Promise<void> {
    await cacheManager.clear();
  }

  async cleanExpiredCache(): Promise<void> {
    await cacheManager.cleanExpired();
  }
}

// Export singleton instance
export const apiClient = new ApiClient();
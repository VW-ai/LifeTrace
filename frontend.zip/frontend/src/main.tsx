/**
 * Application Entry Point
 *
 * Main React entry point following FRONTEND_UPDATE_PLAN.md specifications.
 * Atomic responsibility: application bootstrapping only.
 */

import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import './styles/globals.css';

// Initialize the application
ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
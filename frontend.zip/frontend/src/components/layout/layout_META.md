# Layout Components Module

## Purpose
This module provides the core layout components that implement the Information Architecture from FRONTEND_UPDATE_PLAN.md. These components handle the global application shell: navigation, sidebar, main canvas, event drawer, and status bar.

## Core Logic
- **Information Architecture**: Implements the specified layout structure
- **Responsive Design**: Adapts to different screen sizes following breakpoints
- **State Integration**: Connected to global store for layout state management
- **Accessibility**: Proper semantic HTML and ARIA labels

## File Structure
```
layout/
├── layout_META.md          # This documentation
├── Navigation.tsx           # Top navigation bar
├── Sidebar.tsx              # Left rail with filter controls
├── MainCanvas.tsx           # Central content area with hero canvas
├── EventDrawer.tsx          # Right panel for event details
├── StatusBar.tsx            # Bottom status strip
└── index.ts                 # Layout components export
```

## Key Components
1. **Navigation**: Top nav with view switching and global controls
2. **Sidebar**: Left rail with filter summary, active tags, search, compare mode
3. **MainCanvas**: Central area hosting ambient Tag Field and active view
4. **EventDrawer**: Right panel with virtualized event list and details
5. **StatusBar**: Bottom strip with time window, selection count, performance hints

## Layout Structure
```
┌─────────────────────────────────────────────────────────────┐
│ Navigation (Timeline | Galaxy | River | Calendar | ...)    │
├─────────────┬───────────────────────────────┬─────────────────┤
│ Sidebar     │ MainCanvas                    │ EventDrawer     │
│ - Filters   │ - TagField (ambient)          │ - Event List    │
│ - Tags      │ - ActiveView (Timeline/etc)   │ - Details       │
│ - Search    │                               │ - Filters       │
│ - Compare   │                               │                 │
├─────────────┴───────────────────────────────┴─────────────────┤
│ StatusBar (time window | selection | performance)           │
└─────────────────────────────────────────────────────────────┘
```

## Responsive Behavior
- **Mobile**: Sidebar collapses to overlay, drawer converts to modal
- **Tablet**: Sidebar stays visible, drawer optional
- **Desktop**: Full layout with optional drawer

## Integration Points
- Connected to Zustand store for layout state
- Receives view switching events from Navigation
- Handles filter updates from Sidebar
- Manages event selection in EventDrawer
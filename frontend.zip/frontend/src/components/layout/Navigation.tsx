/**
 * Navigation Component - Top Navigation Bar
 *
 * Temporary placeholder for navigation component.
 */

import React from 'react';
import styled from 'styled-components';
import { useStore } from '../../store';
import { tokens } from '../../design-system';

const Nav = styled.nav`
  height: 64px;
  background: ${tokens.colors.surface[1]};
  border-bottom: 1px solid ${tokens.colors.stroke.soft};
  display: flex;
  align-items: center;
  padding: 0 ${tokens.spacing[6]};
  position: sticky;
  top: 0;
  z-index: ${tokens.zIndex.sticky};
`;

const NavTitle = styled.h1`
  font-size: ${tokens.typography.fontSize['2xl']};
  font-weight: ${tokens.typography.fontWeight.bold};
  color: ${tokens.colors.text.primary};
  margin: 0;
`;

const ViewTabs = styled.div`
  display: flex;
  margin-left: auto;
  gap: ${tokens.spacing[2]};
`;

const ViewTab = styled.button<{ $active: boolean }>`
  padding: ${tokens.spacing[2]} ${tokens.spacing[4]};
  border: none;
  border-radius: ${tokens.radius.base};
  background: ${props => props.$active ? tokens.colors.accent : 'transparent'};
  color: ${props => props.$active ? tokens.colors.text.primary : tokens.colors.text.secondary};
  font-size: ${tokens.typography.fontSize.sm};
  cursor: pointer;
  transition: all ${tokens.motion.duration.fast} ${tokens.motion.easing.default};

  &:hover {
    background: ${props => props.$active ? tokens.colors.accent : tokens.colors.surface[2]};
    color: ${tokens.colors.text.primary};
  }
`;

export const Navigation: React.FC = () => {
  const activeView = useStore(state => state.view.active_view);
  const setActiveView = useStore(state => state.setActiveView);

  const views = [
    { key: 'dashboard', label: 'Dashboard' },
    { key: 'timeline', label: 'Timeline' },
    { key: 'galaxy', label: 'Galaxy' },
    { key: 'river', label: 'River' },
    { key: 'calendar', label: 'Calendar' },
    { key: 'chords', label: 'Chords' },
    { key: 'stories', label: 'Stories' }
  ] as const;

  return (
    <Nav>
      <NavTitle>SmartHistory</NavTitle>
      <ViewTabs>
        {views.map(view => (
          <ViewTab
            key={view.key}
            $active={activeView === view.key}
            onClick={() => setActiveView(view.key)}
          >
            {view.label}
          </ViewTab>
        ))}
      </ViewTabs>
    </Nav>
  );
};
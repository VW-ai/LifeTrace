/**
 * StatusBar Component - Bottom Status Strip
 */

import React from 'react';
import styled from 'styled-components';
import { useStore } from '../../store';
import { tokens } from '../../design-system';

const StatusContainer = styled.div`
  height: 32px;
  background: ${tokens.colors.surface[2]};
  border-top: 1px solid ${tokens.colors.stroke.soft};
  display: flex;
  align-items: center;
  padding: 0 ${tokens.spacing[6]};
  font-size: ${tokens.typography.fontSize.xs};
  color: ${tokens.colors.text.muted};
  gap: ${tokens.spacing[6]};
`;

const StatusItem = styled.div`
  display: flex;
  align-items: center;
  gap: ${tokens.spacing[2]};
`;

export const StatusBar: React.FC = () => {
  const filters = useStore(state => state.filters);
  const data = useStore(state => state.data);
  const performance = useStore(state => state.performance);

  const formatTimeWindow = () => {
    const start = new Date(filters.time_window.start).toLocaleDateString();
    const end = new Date(filters.time_window.end).toLocaleDateString();
    return `${start} - ${end}`;
  };

  return (
    <StatusContainer>
      <StatusItem>
        Time Window: {formatTimeWindow()}
      </StatusItem>
      <StatusItem>
        Events: {data.events.length}
      </StatusItem>
      <StatusItem>
        Selected Tags: {filters.included_tags.length}
      </StatusItem>
      {performance.is_large_data_mode && (
        <StatusItem style={{ color: tokens.colors.warning }}>
          Large Data Mode
        </StatusItem>
      )}
    </StatusContainer>
  );
};
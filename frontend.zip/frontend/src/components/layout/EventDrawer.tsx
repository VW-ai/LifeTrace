/**
 * EventDrawer Component - Right Panel for Event Details
 */

import React from 'react';
import styled from 'styled-components';
import { tokens } from '../../design-system';

const DrawerContainer = styled.aside`
  width: 400px;
  background: ${tokens.colors.surface[1]};
  border-left: 1px solid ${tokens.colors.stroke.soft};
  height: 100%;
  padding: ${tokens.spacing[6]};
`;

const DrawerTitle = styled.h2`
  font-size: ${tokens.typography.fontSize.lg};
  font-weight: ${tokens.typography.fontWeight.semibold};
  color: ${tokens.colors.text.primary};
  margin: 0 0 ${tokens.spacing[4]} 0;
`;

export const EventDrawer: React.FC = () => {
  return (
    <DrawerContainer>
      <DrawerTitle>Events</DrawerTitle>
      <p style={{ color: tokens.colors.text.secondary }}>
        Event details will be displayed here
      </p>
    </DrawerContainer>
  );
};
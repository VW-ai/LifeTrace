/**
 * MainCanvas Component - Central Content Area
 */

import React from 'react';
import styled from 'styled-components';
import { tokens } from '../../design-system';

const CanvasContainer = styled.main`
  flex: 1;
  background: ${tokens.colors.background};
  position: relative;
  overflow: hidden;
`;

const ContentArea = styled.div`
  position: relative;
  width: 100%;
  height: 100%;
  padding: ${tokens.spacing[6]};
`;

interface MainCanvasProps {
  children: React.ReactNode;
}

export const MainCanvas: React.FC<MainCanvasProps> = ({ children }) => {
  return (
    <CanvasContainer>
      <ContentArea>
        {children}
      </ContentArea>
    </CanvasContainer>
  );
};
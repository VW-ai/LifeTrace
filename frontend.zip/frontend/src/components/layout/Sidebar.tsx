/**
 * Sidebar Component - Left Rail with Filter Controls
 */

import React from 'react';
import styled from 'styled-components';
import { tokens } from '../../design-system';

const SidebarContainer = styled.div`
  display: flex;
  align-items: center;
  gap: ${tokens.spacing.lg};
  width: 100%;
  flex-wrap: wrap;
`;

const FilterGroup = styled.div`
  display: flex;
  align-items: center;
  gap: ${tokens.spacing.sm};
`;

const FilterLabel = styled.span`
  font-size: ${tokens.typography.fontSize.sm};
  font-weight: ${tokens.typography.fontWeight.medium};
  color: ${tokens.colors.text.secondary};
  margin: 0 0 ${tokens.spacing[4]} 0;
`;

export const Sidebar: React.FC = () => {
  return (
    <SidebarContainer>
      <FilterGroup>
        <FilterLabel>Time Range:</FilterLabel>
        <span style={{ color: tokens.colors.text.primary, fontSize: tokens.typography.fontSize.sm }}>
          Last 30 days
        </span>
      </FilterGroup>

      <FilterGroup>
        <FilterLabel>Sources:</FilterLabel>
        <span style={{ color: tokens.colors.text.primary, fontSize: tokens.typography.fontSize.sm }}>
          All Sources
        </span>
      </FilterGroup>

      <FilterGroup>
        <FilterLabel>Tags:</FilterLabel>
        <span style={{ color: tokens.colors.text.primary, fontSize: tokens.typography.fontSize.sm }}>
          No filters
        </span>
      </FilterGroup>
    </SidebarContainer>
  );
};
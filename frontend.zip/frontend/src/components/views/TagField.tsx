/**
 * TagField Component - Ambient Background Visualization
 */

import React from 'react';
import styled from 'styled-components';
import { tokens } from '../../design-system';

const FieldContainer = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg,
    ${tokens.colors.background} 0%,
    ${tokens.colors.surface[1]} 50%,
    ${tokens.colors.background} 100%
  );
  opacity: 0.3;
  pointer-events: none;
  z-index: -1;
`;

export const TagField: React.FC = () => {
  return <FieldContainer />;
};
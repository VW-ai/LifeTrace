import React from 'react';
import styled from 'styled-components';
import { tokens } from '../../design-system';

const Placeholder = styled.div`
  width: 100%;
  height: 400px;
  background: ${tokens.colors.surface[1]};
  border: 1px solid ${tokens.colors.stroke.soft};
  border-radius: ${tokens.radius.lg};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${tokens.colors.text.secondary};
`;

export const Calendar: React.FC = () => {
  return <Placeholder>Calendar View - Coming Soon</Placeholder>;
};
/**
 * TimeBrush Component - Brush Selection for Timeline
 *
 * Implements brush selection functionality with clear handles and live preview.
 * Atomic responsibility: brush interaction only.
 */

import React, { useRef, useEffect } from 'react';
import styled from 'styled-components';
import * as d3 from 'd3';
import { tokens } from '../../../design-system';
import type { TimeWindow } from '../../../store/types';

interface TimeBrushProps {
  timeDomain: [Date, Date];
  selection: TimeWindow | null;
  onSelectionChange: (selection: TimeWindow | null) => void;
}

const BrushContainer = styled.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 60px;
  background: ${tokens.colors.surface[2]};
  border-top: 1px solid ${tokens.colors.stroke.soft};
`;

const BrushSVG = styled.svg`
  width: 100%;
  height: 100%;
  overflow: visible;
`;

const BrushHandle = styled.rect`
  fill: ${tokens.colors.accent};
  stroke: ${tokens.colors.surface[1]};
  stroke-width: 1;
  cursor: ew-resize;

  &:hover {
    fill: ${tokens.colors.accent};
    opacity: 0.8;
  }
`;

const BRUSH_MARGINS = {
  top: 10,
  right: 20,
  bottom: 10,
  left: 60
};

export const TimeBrush: React.FC<TimeBrushProps> = ({
  timeDomain,
  selection,
  onSelectionChange
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const brushRef = useRef<d3.BrushBehavior<unknown> | null>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    const width = svgRef.current.clientWidth;
    const height = svgRef.current.clientHeight;

    // Clear previous content
    svg.selectAll('*').remove();

    // Create scales
    const xScale = d3.scaleTime()
      .domain(timeDomain)
      .range([BRUSH_MARGINS.left, width - BRUSH_MARGINS.right]);

    // Create brush
    const brush = d3.brushX()
      .extent([
        [BRUSH_MARGINS.left, BRUSH_MARGINS.top],
        [width - BRUSH_MARGINS.right, height - BRUSH_MARGINS.bottom]
      ])
      .on('brush end', (event) => {
        const { selection: brushSelection, type } = event;

        if (brushSelection) {
          const [x0, x1] = brushSelection;
          const startDate = xScale.invert(x0);
          const endDate = xScale.invert(x1);

          const newSelection: TimeWindow = {
            start: startDate.toISOString().split('T')[0],
            end: endDate.toISOString().split('T')[0],
            granularity: 'day'
          };

          onSelectionChange(newSelection);
        } else if (type === 'end') {
          // Selection was cleared
          onSelectionChange(null);
        }
      });

    brushRef.current = brush;

    // Add brush to SVG
    const brushGroup = svg.append('g')
      .attr('class', 'brush')
      .call(brush);

    // Style brush
    brushGroup.selectAll('.overlay')
      .style('fill', 'transparent')
      .style('cursor', 'crosshair');

    brushGroup.selectAll('.selection')
      .style('fill', tokens.colors.accent)
      .style('fill-opacity', 0.2)
      .style('stroke', tokens.colors.accent)
      .style('stroke-width', 1);

    brushGroup.selectAll('.handle')
      .style('fill', tokens.colors.accent)
      .style('stroke', tokens.colors.surface[1])
      .style('stroke-width', 1)
      .style('cursor', 'ew-resize');

    // Add axis
    const xAxis = d3.axisBottom(xScale)
      .tickFormat(d3.timeFormat('%m/%d') as any)
      .tickSizeOuter(0)
      .tickSize(-(height - BRUSH_MARGINS.top - BRUSH_MARGINS.bottom));

    svg.append('g')
      .attr('class', 'brush-axis')
      .attr('transform', `translate(0, ${height - BRUSH_MARGINS.bottom})`)
      .call(xAxis)
      .selectAll('text')
      .style('fill', tokens.colors.text.muted)
      .style('font-size', tokens.typography.fontSize.xs);

    // Style axis
    svg.selectAll('.brush-axis .domain, .brush-axis .tick line')
      .style('stroke', tokens.colors.stroke.soft)
      .style('opacity', 0.5);

    // Set initial selection if provided
    if (selection) {
      const startDate = new Date(selection.start);
      const endDate = new Date(selection.end);
      const x0 = xScale(startDate);
      const x1 = xScale(endDate);

      brushGroup.call(brush.move, [x0, x1]);
    }

    // Add clear button
    if (selection) {
      const clearButton = svg.append('g')
        .attr('class', 'clear-button')
        .attr('transform', `translate(${width - 40}, 5)`)
        .style('cursor', 'pointer')
        .on('click', () => {
          onSelectionChange(null);
          brushGroup.call(brush.clear);
        });

      clearButton.append('circle')
        .attr('r', 10)
        .style('fill', tokens.colors.surface[3])
        .style('stroke', tokens.colors.stroke.soft);

      clearButton.append('text')
        .text('×')
        .attr('text-anchor', 'middle')
        .attr('dy', '0.35em')
        .style('fill', tokens.colors.text.secondary)
        .style('font-size', '12px')
        .style('font-weight', 'bold');
    }

    // Add labels for current selection
    if (selection) {
      const startDate = new Date(selection.start);
      const endDate = new Date(selection.end);
      const x0 = xScale(startDate);
      const x1 = xScale(endDate);

      // Start label
      svg.append('text')
        .attr('x', x0)
        .attr('y', BRUSH_MARGINS.top - 2)
        .attr('text-anchor', 'middle')
        .style('fill', tokens.colors.text.primary)
        .style('font-size', tokens.typography.fontSize.xs)
        .style('font-weight', tokens.typography.fontWeight.medium)
        .text(d3.timeFormat('%m/%d')(startDate));

      // End label
      svg.append('text')
        .attr('x', x1)
        .attr('y', BRUSH_MARGINS.top - 2)
        .attr('text-anchor', 'middle')
        .style('fill', tokens.colors.text.primary)
        .style('font-size', tokens.typography.fontSize.xs)
        .style('font-weight', tokens.typography.fontWeight.medium)
        .text(d3.timeFormat('%m/%d')(endDate));
    }

    // Cleanup
    return () => {
      svg.selectAll('*').remove();
      brushRef.current = null;
    };
  }, [timeDomain, selection, onSelectionChange]);

  return (
    <BrushContainer>
      <BrushSVG ref={svgRef} />
    </BrushContainer>
  );
};
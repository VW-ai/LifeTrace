/**
 * Timeline Component - Brushable Time Band Visualization
 *
 * Implements zoomable time band with tag pills, brush selection, and source grouping
 * following FRONTEND_UPDATE_PLAN.md specifications. Atomic responsibility: timeline visualization only.
 */

import React, { useRef, useEffect, useMemo, useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import * as d3 from 'd3';
import { useStore, useFilteredEvents } from '../../../store';
import { tokens, getTagColor } from '../../../design-system';
import { TimeBrush } from './TimeBrush';
import { TagPills } from './TagPills';
import { Tooltip } from '../../ui/Tooltip';

// Container and layout
const TimelineContainer = styled.div`
  width: 100%;
  min-height: 400px;
  height: 40vh;
  max-height: 600px;
  background: ${tokens.colors.surface[1]};
  border: 1px solid ${tokens.colors.stroke.soft};
  border-radius: ${tokens.radius.lg};
  position: relative;
  overflow: visible;
  display: flex;
  flex-direction: column;
`;

const TimelineHeader = styled.div`
  padding: ${tokens.spacing[4]};
  border-bottom: 1px solid ${tokens.colors.stroke.soft};
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const TimelineTitle = styled.h3`
  font-size: ${tokens.typography.fontSize.lg};
  font-weight: ${tokens.typography.fontWeight.semibold};
  color: ${tokens.colors.text.primary};
  margin: 0;
`;

const TimelineControls = styled.div`
  display: flex;
  align-items: center;
  gap: ${tokens.spacing[3]};
`;

const SourceToggle = styled.button<{ $active: boolean }>`
  padding: ${tokens.spacing[1]} ${tokens.spacing[3]};
  border-radius: ${tokens.radius.base};
  font-size: ${tokens.typography.fontSize.sm};
  font-weight: ${tokens.typography.fontWeight.medium};
  background: ${props => props.$active ? tokens.colors.accent : 'transparent'};
  color: ${props => props.$active ? tokens.colors.text.primary : tokens.colors.text.secondary};
  border: 1px solid ${props => props.$active ? tokens.colors.accent : tokens.colors.stroke.soft};
  cursor: pointer;
  transition: all ${tokens.motion.duration.fast} ${tokens.motion.easing.default};

  &:hover {
    background: ${props => props.active ? tokens.colors.accent : tokens.colors.surface[2]};
    color: ${tokens.colors.text.primary};
  }
`;

const SVGContainer = styled.svg`
  width: 100%;
  height: calc(100% - 64px); /* Account for header */
  min-height: 300px;
  overflow: visible;
`;

// Types
interface TimelineEvent {
  id: string;
  date: Date;
  time: string;
  summary: string;
  tags: string[];
  source: 'google_calendar' | 'notion' | 'manual';
  duration_minutes: number;
}

interface TimelineTooltip {
  x: number;
  y: number;
  event: TimelineEvent;
}

const MARGINS = {
  top: 20,
  right: 20,
  bottom: 60,
  left: 60
};

const LANE_HEIGHT = 30;
const SOURCE_COLORS = {
  google_calendar: tokens.colors.accent,
  notion: '#10b981',
  manual: '#f59e0b'
};

export const Timeline: React.FC = () => {
  const svgRef = useRef<SVGSVGElement>(null);
  const events = useFilteredEvents();
  const brushSelection = useStore(state => state.view.brush_selection);
  const setBrushSelection = useStore(state => state.setBrushSelection);
  const selectedTags = useStore(state => state.view.selected_tags);
  const setSelectedTags = useStore(state => state.setSelectedTags);
  const addTagFilter = useStore(state => state.addTagFilter);
  const [visibleSources, setVisibleSources] = useState<Set<string>>(
    new Set(['google_calendar', 'notion', 'manual'])
  );
  const [tooltip, setTooltip] = useState<TimelineTooltip | null>(null);

  // Transform events data
  const timelineEvents: TimelineEvent[] = useMemo(() => {
    return events
      .filter(event => visibleSources.has(event.source))
      .map(event => ({
        id: event.id,
        date: new Date(event.date),
        time: event.time,
        summary: event.summary,
        tags: event.selected_tags || [],
        source: event.source,
        duration_minutes: event.duration_minutes || 60
      }))
      .sort((a, b) => a.date.getTime() - b.date.getTime());
  }, [events, visibleSources]);

  // Calculate time domain
  const timeDomain = useMemo(() => {
    if (timelineEvents.length === 0) {
      const now = new Date();
      return [d3.timeDay.offset(now, -30), now];
    }

    const extent = d3.extent(timelineEvents, d => d.date) as [Date, Date];
    // Add padding
    const padding = (extent[1].getTime() - extent[0].getTime()) * 0.05;
    return [
      new Date(extent[0].getTime() - padding),
      new Date(extent[1].getTime() + padding)
    ];
  }, [timelineEvents]);

  // Group events by source for lanes
  const eventLanes = useMemo(() => {
    const sources = Array.from(visibleSources);
    return sources.map(source => ({
      source,
      events: timelineEvents.filter(e => e.source === source),
      color: SOURCE_COLORS[source as keyof typeof SOURCE_COLORS]
    }));
  }, [timelineEvents, visibleSources]);

  useEffect(() => {
    if (!svgRef.current || timelineEvents.length === 0) return;

    const svg = d3.select(svgRef.current);
    const width = svgRef.current.clientWidth;
    const height = svgRef.current.clientHeight;

    // Clear previous content
    svg.selectAll('*').remove();

    // Create scales
    const xScale = d3.scaleTime()
      .domain(timeDomain)
      .range([MARGINS.left, width - MARGINS.right]);

    const yScale = d3.scaleBand()
      .domain(eventLanes.map(lane => lane.source))
      .range([MARGINS.top, height - MARGINS.bottom])
      .padding(0.2);

    // Create container group
    const container = svg.append('g');

    // Add axes
    const xAxis = d3.axisBottom(xScale)
      .tickFormat(d3.timeFormat('%m/%d') as any)
      .tickSizeOuter(0)
      .ticks(Math.max(2, Math.floor(width / 80)));

    container.append('g')
      .attr('class', 'x-axis')
      .attr('transform', `translate(0, ${height - MARGINS.bottom})`)
      .call(xAxis)
      .selectAll('text')
      .style('fill', tokens.colors.text.secondary)
      .style('font-size', tokens.typography.fontSize.sm)
      .style('text-anchor', 'middle');

    container.append('g')
      .attr('class', 'y-axis')
      .attr('transform', `translate(${MARGINS.left}, 0)`)
      .call(d3.axisLeft(yScale).tickSizeOuter(0))
      .selectAll('text')
      .style('fill', tokens.colors.text.secondary)
      .style('font-size', tokens.typography.fontSize.sm);

    // Style axes
    container.selectAll('.domain, .tick line')
      .style('stroke', tokens.colors.stroke.soft);

    // Add brush selection overlay if active
    if (brushSelection) {
      const brushStart = new Date(brushSelection.start);
      const brushEnd = new Date(brushSelection.end);

      container.append('rect')
        .attr('class', 'brush-selection')
        .attr('x', xScale(brushStart))
        .attr('y', MARGINS.top)
        .attr('width', xScale(brushEnd) - xScale(brushStart))
        .attr('height', height - MARGINS.top - MARGINS.bottom)
        .style('fill', tokens.colors.accent)
        .style('opacity', 0.1)
        .style('pointer-events', 'none');
    }

    // Add event lanes
    eventLanes.forEach(lane => {
      const laneY = yScale(lane.source)!;
      const laneHeight = yScale.bandwidth();

      // Lane background
      container.append('rect')
        .attr('class', `lane-${lane.source}`)
        .attr('x', MARGINS.left)
        .attr('y', laneY)
        .attr('width', width - MARGINS.left - MARGINS.right)
        .attr('height', laneHeight)
        .style('fill', lane.color)
        .style('opacity', 0.05);

      // Events in this lane
      const eventGroup = container.append('g')
        .attr('class', `events-${lane.source}`);

      const eventRects = eventGroup.selectAll('.event')
        .data(lane.events)
        .enter()
        .append('g')
        .attr('class', 'event-group')
        .attr('transform', d => `translate(${xScale(d.date)}, ${laneY})`);

      // Event rectangles
      eventRects.append('rect')
        .attr('class', 'event')
        .attr('x', -2)
        .attr('y', 2)
        .attr('width', 4)
        .attr('height', laneHeight - 4)
        .style('fill', lane.color)
        .style('opacity', d => selectedTags.length === 0 || d.tags.some(tag => selectedTags.includes(tag)) ? 0.8 : 0.3)
        .style('cursor', 'pointer')
        .on('mouseenter', function(event, d) {
          d3.select(this).style('opacity', 1);
          const rect = (event.currentTarget as SVGRectElement).getBoundingClientRect();
          setTooltip({
            x: rect.left + rect.width / 2,
            y: rect.top,
            event: d
          });
        })
        .on('mouseleave', function(event, d) {
          d3.select(this).style('opacity',
            selectedTags.length === 0 || d.tags.some(tag => selectedTags.includes(tag)) ? 0.8 : 0.3
          );
          setTooltip(null);
        })
        .on('click', (event, d) => {
          // Toggle event selection or filter by first tag
          if (d.tags.length > 0) {
            addTagFilter(d.tags[0]);
          }
        });

      // Add tag indicators for events with multiple tags
      eventRects.each(function(d) {
        if (d.tags.length > 1) {
          d3.select(this.parentNode)
            .append('circle')
            .attr('cx', 0)
            .attr('cy', laneHeight / 2)
            .attr('r', 3)
            .style('fill', getTagColor(d.tags[0]))
            .style('stroke', tokens.colors.surface[1])
            .style('stroke-width', 1)
            .style('cursor', 'pointer');
        }
      });
    });

    // Add zoom behavior
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.5, 10])
      .on('zoom', (event) => {
        const { transform } = event;

        // Update x scale
        const newXScale = transform.rescaleX(xScale);

        // Update axis
        container.select('.x-axis')
          .call(d3.axisBottom(newXScale).tickFormat(d3.timeFormat('%m/%d') as any).ticks(Math.max(2, Math.floor(width / 80))))
          .selectAll('text')
          .style('text-anchor', 'middle');

        // Update events
        eventLanes.forEach(lane => {
          container.select(`.events-${lane.source}`)
            .selectAll('.event-group')
            .attr('transform', (d: any) => `translate(${newXScale(d.date)}, ${yScale(lane.source)})`);
        });

        // Update brush selection if active
        if (brushSelection) {
          const brushStart = new Date(brushSelection.start);
          const brushEnd = new Date(brushSelection.end);

          container.select('.brush-selection')
            .attr('x', newXScale(brushStart))
            .attr('width', newXScale(brushEnd) - newXScale(brushStart));
        }
      });

    svg.call(zoom);

    // Cleanup
    return () => {
      svg.selectAll('*').remove();
    };
  }, [timelineEvents, timeDomain, eventLanes, brushSelection, selectedTags, addTagFilter]);

  const toggleSource = (source: string) => {
    const newSources = new Set(visibleSources);
    if (newSources.has(source)) {
      newSources.delete(source);
    } else {
      newSources.add(source);
    }
    setVisibleSources(newSources);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.2, 0.8, 0.2, 1] }}
    >
      <TimelineContainer>
        <TimelineHeader>
          <TimelineTitle>Activity Timeline</TimelineTitle>
          <TimelineControls>
            {Object.entries(SOURCE_COLORS).map(([source, color]) => (
              <SourceToggle
                key={source}
$active={visibleSources.has(source)}
                onClick={() => toggleSource(source)}
              >
                <div style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  background: color,
                  display: 'inline-block',
                  marginRight: '6px'
                }} />
                {source.replace('_', ' ')}
              </SourceToggle>
            ))}
          </TimelineControls>
        </TimelineHeader>

        <SVGContainer ref={svgRef} />

        {/* Brush component will be added here */}
        <TimeBrush
          timeDomain={timeDomain}
          selection={brushSelection}
          onSelectionChange={setBrushSelection}
        />

        {/* Tag pills overlay */}
        <TagPills events={timelineEvents} />
      </TimelineContainer>

      {/* Tooltip */}
      {tooltip && (
        <Tooltip
          x={tooltip.x}
          y={tooltip.y}
          content={
            <div>
              <div style={{ fontWeight: 600, marginBottom: '4px' }}>
                {tooltip.event.summary}
              </div>
              <div style={{ fontSize: '12px', opacity: 0.8 }}>
                {tooltip.event.date.toLocaleDateString()} at {tooltip.event.time}
              </div>
              {tooltip.event.tags.length > 0 && (
                <div style={{ fontSize: '12px', marginTop: '4px' }}>
                  Tags: {tooltip.event.tags.join(', ')}
                </div>
              )}
            </div>
          }
        />
      )}
    </motion.div>
  );
};
/**
 * TagPills Component - Tag Visualization on Timeline
 *
 * Displays tag pills overlaid on timeline events with clustering and interaction.
 * Atomic responsibility: tag pill rendering and interaction only.
 */

import React, { useMemo, useState } from 'react';
import styled from 'styled-components';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '../../../store';
import { tokens, getTagColor } from '../../../design-system';

interface TagPillsProps {
  events: Array<{
    id: string;
    date: Date;
    tags: string[];
    source: string;
  }>;
}

const PillsContainer = styled.div`
  position: absolute;
  top: 64px; /* Below header */
  left: 60px; /* Align with timeline margins */
  right: 20px;
  bottom: 60px; /* Above brush */
  pointer-events: none;
  overflow: hidden;
`;

const TagPill = styled(motion.div)<{ color: string; $active: boolean }>`
  position: absolute;
  padding: ${tokens.spacing[1]} ${tokens.spacing[2]};
  border-radius: ${tokens.radius.full};
  font-size: ${tokens.typography.fontSize.xs};
  font-weight: ${tokens.typography.fontWeight.medium};
  background: ${props => props.$active ? props.color : 'transparent'};
  color: ${props => props.$active ? tokens.colors.background : props.color};
  border: 1px solid ${props => props.color};
  cursor: pointer;
  pointer-events: auto;
  user-select: none;
  white-space: nowrap;
  backdrop-filter: blur(4px);
  transition: all ${tokens.motion.duration.fast} ${tokens.motion.easing.default};

  &:hover {
    background: ${props => props.color};
    color: ${tokens.colors.background};
    transform: translateY(-1px);
    box-shadow: 0 2px 8px ${props => props.color}40;
  }
`;

const TagCluster = styled.div`
  position: absolute;
  display: flex;
  flex-wrap: wrap;
  gap: ${tokens.spacing[1]};
  max-width: 200px;
`;

const ClusterCount = styled.div<{ color: string }>`
  padding: ${tokens.spacing[1]} ${tokens.spacing[2]};
  border-radius: ${tokens.radius.full};
  font-size: ${tokens.typography.fontSize.xs};
  font-weight: ${tokens.typography.fontWeight.bold};
  background: ${props => props.color};
  color: ${tokens.colors.background};
  border: 1px solid ${props => props.color};
  cursor: pointer;
  pointer-events: auto;
  min-width: 24px;
  text-align: center;
`;

// Cluster nearby tags to reduce visual clutter
const clusterTags = (
  events: TagPillsProps['events'],
  containerWidth: number
): Array<{
  x: number;
  y: number;
  tags: Array<{ tag: string; count: number; events: string[] }>;
  representative: string;
}> => {
  // Group events by time buckets
  const timeBuckets: Record<string, Array<{ tags: string[]; id: string }>> = {};
  const timeRange = events.length > 0 ?
    [Math.min(...events.map(e => e.date.getTime())), Math.max(...events.map(e => e.date.getTime()))] :
    [Date.now(), Date.now()];

  const bucketSize = (timeRange[1] - timeRange[0]) / Math.max(1, containerWidth / 100); // ~100px buckets

  events.forEach(event => {
    const bucketKey = Math.floor((event.date.getTime() - timeRange[0]) / bucketSize).toString();
    if (!timeBuckets[bucketKey]) timeBuckets[bucketKey] = [];
    timeBuckets[bucketKey].push({ tags: event.tags, id: event.id });
  });

  // Create clusters
  return Object.entries(timeBuckets).map(([bucketKey, bucketEvents], index) => {
    const tagCounts: Record<string, { count: number; events: string[] }> = {};

    bucketEvents.forEach(({ tags, id }) => {
      tags.forEach(tag => {
        if (!tagCounts[tag]) tagCounts[tag] = { count: 0, events: [] };
        tagCounts[tag].count++;
        tagCounts[tag].events.push(id);
      });
    });

    const sortedTags = Object.entries(tagCounts)
      .map(([tag, data]) => ({ tag, ...data }))
      .sort((a, b) => b.count - a.count);

    const x = (parseInt(bucketKey) / Object.keys(timeBuckets).length) * containerWidth;
    const y = (index % 3) * 40 + 20; // Distribute vertically

    return {
      x,
      y,
      tags: sortedTags,
      representative: sortedTags[0]?.tag || ''
    };
  }).filter(cluster => cluster.tags.length > 0);
};

export const TagPills: React.FC<TagPillsProps> = ({ events }) => {
  const selectedTags = useStore(state => state.view.selected_tags);
  const addTagFilter = useStore(state => state.addTagFilter);
  const removeTagFilter = useStore(state => state.removeTagFilter);
  const [expandedCluster, setExpandedCluster] = useState<number | null>(null);

  const clusters = useMemo(() => {
    // Use a fixed width for calculations - this would ideally come from a ref
    return clusterTags(events, 800);
  }, [events]);

  const handleTagClick = (tag: string) => {
    if (selectedTags.includes(tag)) {
      removeTagFilter(tag);
    } else {
      addTagFilter(tag);
    }
  };

  const handleClusterClick = (clusterIndex: number) => {
    setExpandedCluster(expandedCluster === clusterIndex ? null : clusterIndex);
  };

  return (
    <PillsContainer>
      <AnimatePresence>
        {clusters.map((cluster, clusterIndex) => (
          <TagCluster
            key={clusterIndex}
            style={{
              left: `${(cluster.x / 800) * 100}%`,
              top: cluster.y
            }}
          >
            {expandedCluster === clusterIndex ? (
              // Expanded view showing individual tags
              cluster.tags.slice(0, 5).map(({ tag, count }, tagIndex) => (
                <TagPill
                  key={tag}
                  color={getTagColor(tag)}
$active={selectedTags.includes(tag)}
                  onClick={() => handleTagClick(tag)}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{
                    duration: 0.15,
                    delay: tagIndex * 0.03,
                    ease: [0.2, 0.8, 0.2, 1]
                  }}
                >
                  {tag} {count > 1 && `(${count})`}
                </TagPill>
              ))
            ) : (
              // Collapsed view showing cluster summary
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.15 }}
              >
                {cluster.tags.length === 1 ? (
                  // Single tag
                  <TagPill
                    color={getTagColor(cluster.representative)}
$active={selectedTags.includes(cluster.representative)}
                    onClick={() => handleTagClick(cluster.representative)}
                  >
                    {cluster.representative}
                    {cluster.tags[0].count > 1 && ` (${cluster.tags[0].count})`}
                  </TagPill>
                ) : (
                  // Multiple tags - show count
                  <ClusterCount
                    color={getTagColor(cluster.representative)}
                    onClick={() => handleClusterClick(clusterIndex)}
                    title={`${cluster.tags.length} tags: ${cluster.tags.map(t => t.tag).join(', ')}`}
                  >
                    {cluster.tags.length}
                  </ClusterCount>
                )}
              </motion.div>
            )}
          </TagCluster>
        ))}
      </AnimatePresence>
    </PillsContainer>
  );
};
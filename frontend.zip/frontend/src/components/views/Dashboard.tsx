import React from 'react';
import styled from 'styled-components';
import { tokens } from '../../design-system';
import { Timeline } from './Timeline';
import { Galaxy } from './Galaxy';
import { River } from './River';
import { Calendar } from './Calendar';
import { TagField } from './TagField';

const DashboardContainer = styled.div`
  width: 100%;
  height: 100%;
  overflow-y: auto;
  padding: ${tokens.spacing.lg};
  background: ${tokens.colors.background};
`;

const DashboardHeader = styled.div`
  margin-bottom: ${tokens.spacing.xl};
`;

const DashboardTitle = styled.h1`
  font-size: ${tokens.typography.fontSize['2xl']};
  font-weight: ${tokens.typography.fontWeight.bold};
  color: ${tokens.colors.text.primary};
  margin: 0 0 ${tokens.spacing.sm} 0;
`;

const DashboardSubtitle = styled.p`
  font-size: ${tokens.typography.fontSize.lg};
  color: ${tokens.colors.text.secondary};
  margin: 0;
`;

const GridLayout = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-template-rows: auto auto auto;
  gap: ${tokens.spacing.lg};
  height: calc(100% - 120px);

  @media (max-width: 1200px) {
    grid-template-columns: 1fr;
    grid-template-rows: auto;
  }
`;

const ViewCard = styled.div<{ $spanning?: boolean }>`
  background: ${tokens.colors.surface[1]};
  border: 1px solid ${tokens.colors.stroke.soft};
  border-radius: ${tokens.radius.lg};
  padding: ${tokens.spacing.lg};
  position: relative;
  min-height: 300px;

  ${props => props.$spanning && `
    grid-column: 1 / -1;
  `}
`;

const CardHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: ${tokens.spacing.md};
  padding-bottom: ${tokens.spacing.sm};
  border-bottom: 1px solid ${tokens.colors.stroke.soft};
`;

const CardTitle = styled.h3`
  font-size: ${tokens.typography.fontSize.lg};
  font-weight: ${tokens.typography.fontWeight.semibold};
  color: ${tokens.colors.text.primary};
  margin: 0;
`;

const ViewButton = styled.button`
  padding: ${tokens.spacing.xs} ${tokens.spacing.sm};
  background: transparent;
  border: 1px solid ${tokens.colors.stroke.soft};
  border-radius: ${tokens.radius.base};
  color: ${tokens.colors.text.secondary};
  font-size: ${tokens.typography.fontSize.xs};
  cursor: pointer;
  transition: all ${tokens.motion.duration.fast} ${tokens.motion.easing.default};

  &:hover {
    background: ${tokens.colors.surface[2]};
    border-color: ${tokens.colors.stroke.emphasis};
    color: ${tokens.colors.text.primary};
  }
`;

const ViewContent = styled.div`
  height: calc(100% - 60px);
  position: relative;
`;

export const Dashboard: React.FC = () => {
  return (
    <DashboardContainer>
      <DashboardHeader>
        <DashboardTitle>Activity Analytics Dashboard</DashboardTitle>
        <DashboardSubtitle>
          Your comprehensive view of time patterns, tag relationships, and productivity insights
        </DashboardSubtitle>
      </DashboardHeader>

      <GridLayout>
        {/* Tag Field - Full width ambient background */}
        <ViewCard $spanning>
          <CardHeader>
            <CardTitle>Tag Field</CardTitle>
            <ViewButton>Focus View</ViewButton>
          </CardHeader>
          <ViewContent>
            <TagField />
          </ViewContent>
        </ViewCard>

        {/* Timeline */}
        <ViewCard>
          <CardHeader>
            <CardTitle>Timeline</CardTitle>
            <ViewButton>Focus View</ViewButton>
          </CardHeader>
          <ViewContent>
            <Timeline />
          </ViewContent>
        </ViewCard>

        {/* Calendar */}
        <ViewCard>
          <CardHeader>
            <CardTitle>Calendar</CardTitle>
            <ViewButton>Focus View</ViewButton>
          </CardHeader>
          <ViewContent>
            <Calendar />
          </ViewContent>
        </ViewCard>

        {/* Galaxy */}
        <ViewCard>
          <CardHeader>
            <CardTitle>Tag Galaxy</CardTitle>
            <ViewButton>Focus View</ViewButton>
          </CardHeader>
          <ViewContent>
            <Galaxy />
          </ViewContent>
        </ViewCard>

        {/* River */}
        <ViewCard>
          <CardHeader>
            <CardTitle>Tag River</CardTitle>
            <ViewButton>Focus View</ViewButton>
          </CardHeader>
          <ViewContent>
            <River />
          </ViewContent>
        </ViewCard>
      </GridLayout>
    </DashboardContainer>
  );
};
# Views Components Module

## Purpose
This module implements the key visualization views from FRONTEND_UPDATE_PLAN.md: Timeline, Galaxy, River, Calendar, Chords, and Stories. Each view provides different perspectives on the tag-driven activity data with cross-filtering capabilities.

## Core Logic
- **Timeline**: Zoomable time band with tag pills, brush selection, source grouping
- **Galaxy**: Force-directed graph of tags with co-occurrence edges and lasso selection
- **River**: Stacked streamgraph of tag volumes over time with multiple modes
- **Calendar**: Month heatmap with radial day clock for hourly patterns
- **Chords**: Tag-to-tag transitions with directional flow visualization
- **Stories**: Saved filter states with sharing capabilities

## File Structure
```
views/
├── views_META.md           # This documentation
├── TagField.tsx            # Ambient Voronoi/particle background
├── Timeline/
│   ├── Timeline.tsx        # Main timeline component
│   ├── TimeBrush.tsx       # Brush selection functionality
│   ├── TagPills.tsx        # Tag visualization on timeline
│   └── index.ts            # Timeline exports
├── Galaxy/
├── River/
├── Calendar/
├── Chords/
├── Stories/
└── index.ts                # All views export
```

## Key Features (Phase 1 Focus)
1. **Timeline**: Brushable time band with tag pills, source grouping, zoom/pan
2. **Cross-filtering**: All views respond to filter changes from global state
3. **Interactive**: Click/hover behaviors with tooltip previews
4. **Performance**: Optimized for large datasets with virtualization

## Integration Points
- Connected to Zustand store for data and filter state
- Uses design system tokens for consistent styling
- Implements motion specifications from design system
- Follows accessibility guidelines for keyboard navigation

## Technical Implementation
- D3.js for data visualization and interactions
- React for component lifecycle and state management
- Framer Motion for smooth transitions
- Styled Components for theme integration
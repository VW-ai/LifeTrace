/**
 * Tooltip Component - Floating Tooltip with Portal
 *
 * Reusable tooltip component with positioning and portal rendering.
 * Atomic responsibility: tooltip rendering only.
 */

import React from 'react';
import { createPortal } from 'react-dom';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { tokens } from '../../design-system';

interface TooltipProps {
  x: number;
  y: number;
  content: React.ReactNode;
  anchor?: 'top' | 'bottom' | 'left' | 'right';
}

const TooltipContainer = styled(motion.div)<{ x: number; y: number; anchor: string }>`
  position: fixed;
  z-index: ${tokens.zIndex.tooltip};
  background: ${tokens.colors.surface[3]};
  border: 1px solid ${tokens.colors.stroke.soft};
  border-radius: ${tokens.radius.base};
  padding: ${tokens.spacing[3]};
  box-shadow: ${tokens.elevation[2]};
  backdrop-filter: blur(8px);
  font-size: ${tokens.typography.fontSize.sm};
  max-width: 300px;
  pointer-events: none;

  ${props => {
    switch (props.anchor) {
      case 'top':
        return `
          left: ${props.x}px;
          bottom: ${window.innerHeight - props.y + 8}px;
          transform: translateX(-50%);
        `;
      case 'bottom':
        return `
          left: ${props.x}px;
          top: ${props.y + 8}px;
          transform: translateX(-50%);
        `;
      case 'left':
        return `
          right: ${window.innerWidth - props.x + 8}px;
          top: ${props.y}px;
          transform: translateY(-50%);
        `;
      case 'right':
        return `
          left: ${props.x + 8}px;
          top: ${props.y}px;
          transform: translateY(-50%);
        `;
      default:
        return `
          left: ${props.x}px;
          top: ${props.y - 8}px;
          transform: translate(-50%, -100%);
        `;
    }
  }}
`;

export const Tooltip: React.FC<TooltipProps> = ({
  x,
  y,
  content,
  anchor = 'top'
}) => {
  return createPortal(
    <TooltipContainer
      x={x}
      y={y}
      anchor={anchor}
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{
        duration: 0.15,
        ease: [0.2, 0.8, 0.2, 1]
      }}
    >
      {content}
    </TooltipContainer>,
    document.body
  );
};
/**
 * Type Definitions - Tag-Driven Visualization
 *
 * Core type definitions for events, aggregations, and UI state
 * following the FRONTEND_UPDATE_PLAN.md data model.
 */

// Core Event Type (from backend)
export interface Event {
  id: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  source: 'google_calendar' | 'notion' | 'manual';
  summary: string;
  details: string;
  selected_tags: string[];
  duration_minutes?: number;
  processed_at?: string;
}

// Derived Aggregations (from backend services)
export interface TagSummary {
  tag: string;
  count: number;
  total_minutes: number;
  color: string;
  first_seen: string;
  last_seen: string;
}

export interface TagCooccurrence {
  tag_a: string;
  tag_b: string;
  count: number;
  jaccard_similarity: number;
  strength: number; // normalized 0-1
}

export interface TagTransition {
  from_tag: string;
  to_tag: string;
  count: number;
  avg_time_between_minutes: number;
  direction: 'forward' | 'backward';
}

export interface TagCluster {
  cluster_id: string;
  tags: string[];
  coherence_score: number;
  representative_tag: string;
}

export interface TagTimeSeries {
  date: string; // YYYY-MM-DD
  hour?: number; // 0-23 for hourly, undefined for daily
  tag: string;
  count: number;
  total_minutes: number;
  normalized_count: number; // 0-1 within time period
  share_of_day: number; // 0-1 share of total activity that day
}

// Time Window & Filtering
export interface TimeWindow {
  start: string; // ISO date
  end: string; // ISO date
  granularity: 'hour' | 'day' | 'week' | 'month';
}

export interface TagFilter {
  included_tags: string[];
  excluded_tags: string[];
  sources: Array<'google_calendar' | 'notion' | 'manual'>;
  time_window: TimeWindow;
}

// UI State Types
export interface ViewState {
  active_view: 'timeline' | 'galaxy' | 'river' | 'calendar' | 'chords' | 'stories';
  is_compare_mode: boolean;
  compare_sets: {
    a: string[]; // tag set A
    b: string[]; // tag set B
  };
  selected_tags: string[];
  hovered_tag: string | null;
  brush_selection: TimeWindow | null;
}

export interface PerformanceState {
  is_large_data_mode: boolean;
  data_size: number;
  render_fps: number;
  last_interaction_time: number;
}

// Component Props Types
export interface FilterChipProps {
  tag: string;
  count: number;
  color: string;
  is_active: boolean;
  is_compare_set?: 'a' | 'b' | null;
  onToggle: (tag: string) => void;
  onRemove: (tag: string) => void;
}

export interface TimelineProps {
  events: Event[];
  time_window: TimeWindow;
  selected_tags: string[];
  brush_selection: TimeWindow | null;
  onBrushChange: (selection: TimeWindow | null) => void;
  onTagClick: (tag: string) => void;
}

export interface TagFrequencyCardProps {
  tag: string;
  summary: TagSummary;
  is_selected: boolean;
  is_compare_set?: 'a' | 'b' | null;
  onClick: (tag: string) => void;
  onCompareToggle?: (tag: string, set: 'a' | 'b') => void;
}

// API Response Types
export interface ApiResponse<T> {
  data: T;
  meta?: {
    total_count?: number;
    page?: number;
    limit?: number;
    cache_key?: string;
  };
  error?: string;
}

export interface EventsResponse extends ApiResponse<Event[]> {}
export interface TagSummaryResponse extends ApiResponse<TagSummary[]> {}
export interface TagCooccurrenceResponse extends ApiResponse<TagCooccurrence[]> {}
export interface TagTransitionsResponse extends ApiResponse<TagTransition[]> {}
export interface TagClustersResponse extends ApiResponse<TagCluster[]> {}
export interface TagTimeSeriesResponse extends ApiResponse<TagTimeSeries[]> {}

// URL State (for shareable stories)
export interface UrlState {
  view?: string;
  tags?: string;
  exclude?: string;
  start?: string;
  end?: string;
  compare?: string;
  story?: string;
}

// Story (saved filter state)
export interface Story {
  id: string;
  name: string;
  description?: string;
  created_at: string;
  filter_state: TagFilter;
  view_state: Partial<ViewState>;
  snapshot_url?: string; // PNG/SVG export
}
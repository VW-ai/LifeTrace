/**
 * Main Application Component
 *
 * Root component implementing the global layout from FRONTEND_UPDATE_PLAN.md.
 * Information Architecture: hero canvas, right panel (Event Drawer), left rail (filters),
 * top nav, bottom status strip. Atomic responsibility: layout orchestration only.
 */

import React, { useEffect } from 'react';
import styled from 'styled-components';
import { useStore, initializeUrlSync } from './store';
import { Navigation } from './components/layout/Navigation';
import { Sidebar } from './components/layout/Sidebar';
import { MainCanvas } from './components/layout/MainCanvas';
import { EventDrawer } from './components/layout/EventDrawer';
import { StatusBar } from './components/layout/StatusBar';
import { TagField } from './components/views/TagField';
import { Timeline } from './components/views/Timeline';
import { Galaxy } from './components/views/Galaxy';
import { River } from './components/views/River';
import { Calendar } from './components/views/Calendar';
import { Chords } from './components/views/Chords';
import { Stories } from './components/views/Stories';
import { Dashboard } from './components/views/Dashboard';
import { tokens } from './design-system';

// Layout container following Information Architecture
const AppContainer = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background: ${tokens.colors.background};
  color: ${tokens.colors.text.primary};
  font-family: ${tokens.typography.fontFamily.sans.join(', ')};
`;

const MainLayout = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  height: calc(100vh - 64px); /* Account for navigation height */
`;

const FilterBanner = styled.div`
  width: 100%;
  background: ${tokens.colors.surface[1]};
  border-bottom: 1px solid ${tokens.colors.stroke.soft};
  padding: ${tokens.spacing.md} ${tokens.spacing.lg};
  display: flex;
  align-items: center;
  gap: ${tokens.spacing.md};
  min-height: 48px;
`;

const ViewArea = styled.div`
  flex: 1;
  width: 100%;
  overflow: hidden;
  position: relative;
`;

// View component mapping
const VIEW_COMPONENTS = {
  dashboard: Dashboard,
  timeline: Timeline,
  galaxy: Galaxy,
  river: River,
  calendar: Calendar,
  chords: Chords,
  stories: Stories
} as const;

export const App: React.FC = () => {
  const activeView = useStore((state) => state.view.active_view);
  const drawerOpen = useStore((state) => state.view.drawer_open);
  const loadAllData = useStore((state) => state.loadAllData);

  // Initialize URL sync and load initial data
  useEffect(() => {
    initializeUrlSync();
    loadAllData();
  }, [loadAllData]);

  // Get active view component
  const ActiveViewComponent = VIEW_COMPONENTS[activeView];

  return (
    <AppContainer>
      {/* Top Navigation */}
      <Navigation />

      <MainLayout>
        {/* Horizontal Filter Banner */}
        <FilterBanner>
          <Sidebar />
        </FilterBanner>

        {/* Full-width View Area */}
        <ViewArea>
          {activeView === 'dashboard' ? (
            <ActiveViewComponent />
          ) : (
            <MainCanvas>
              <TagField />
              <ActiveViewComponent />
            </MainCanvas>
          )}

          {/* Right Panel - Event Drawer */}
          {drawerOpen && <EventDrawer />}
        </ViewArea>
      </MainLayout>

      {/* Bottom Status Strip */}
      <StatusBar />
    </AppContainer>
  );
};
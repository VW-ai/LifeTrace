/**
 * Design System Export
 *
 * Central export point for the complete design system
 */

export * from './tokens';
export * from './components';

// Re-export commonly used utilities
export { getTagColor } from './tokens';
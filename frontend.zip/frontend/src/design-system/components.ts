/**
 * Component Inventory - Reusable UI Primitives
 *
 * Defines the component system for consistent styling across
 * the tag-driven visualization interface.
 */

import { tokens } from './tokens';

// Component Variants
export const buttonVariants = {
  primary: {
    background: tokens.colors.accent,
    color: tokens.colors.text.primary,
    border: 'none',
    '&:hover': {
      background: '#5855eb'
    },
    '&:focus': {
      boxShadow: tokens.a11y.focusRing
    }
  },
  secondary: {
    background: tokens.colors.surface[2],
    color: tokens.colors.text.primary,
    border: `1px solid ${tokens.colors.stroke.soft}`,
    '&:hover': {
      background: tokens.colors.surface[3]
    }
  },
  ghost: {
    background: 'transparent',
    color: tokens.colors.text.secondary,
    border: 'none',
    '&:hover': {
      background: tokens.colors.surface[1],
      color: tokens.colors.text.primary
    }
  }
} as const;

export const cardVariants = {
  default: {
    background: tokens.colors.surface[1],
    border: `1px solid ${tokens.colors.stroke.soft}`,
    borderRadius: tokens.radius.lg,
    boxShadow: tokens.elevation[1]
  },
  elevated: {
    background: tokens.colors.surface[2],
    border: `1px solid ${tokens.colors.stroke.soft}`,
    borderRadius: tokens.radius.lg,
    boxShadow: tokens.elevation[2],
    backdropFilter: 'blur(8px)'
  },
  glass: {
    background: 'rgba(26, 26, 26, 0.8)',
    border: `1px solid ${tokens.colors.stroke.soft}`,
    borderRadius: tokens.radius.lg,
    boxShadow: tokens.elevation[3],
    backdropFilter: 'blur(12px)'
  }
} as const;

export const inputVariants = {
  default: {
    background: tokens.colors.surface[2],
    border: `1px solid ${tokens.colors.stroke.soft}`,
    borderRadius: tokens.radius.base,
    color: tokens.colors.text.primary,
    fontSize: tokens.typography.fontSize.sm,
    padding: `${tokens.spacing[2]} ${tokens.spacing[3]}`,
    '&:focus': {
      outline: 'none',
      borderColor: tokens.colors.accent,
      boxShadow: `0 0 0 1px ${tokens.colors.accent}`
    },
    '&::placeholder': {
      color: tokens.colors.text.muted
    }
  }
} as const;

export const tagChipVariants = {
  default: {
    fontSize: tokens.typography.fontSize.xs,
    fontWeight: tokens.typography.fontWeight.medium,
    padding: `${tokens.spacing[1]} ${tokens.spacing[2]}`,
    borderRadius: tokens.radius.full,
    border: '1px solid',
    cursor: 'pointer',
    transition: `all ${tokens.motion.duration.fast} ${tokens.motion.easing.default}`,
    '&:hover': {
      transform: 'translateY(-1px)'
    }
  },
  active: {
    background: 'currentColor',
    color: tokens.colors.background,
    borderColor: 'currentColor'
  },
  inactive: {
    background: 'transparent',
    color: 'currentColor',
    borderColor: 'currentColor',
    opacity: '0.7'
  }
} as const;

// Animation Presets
export const animations = {
  fadeIn: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 },
    transition: {
      duration: 0.2,
      ease: [0.2, 0.8, 0.2, 1]
    }
  },
  slideUp: {
    initial: { opacity: 0, y: 8 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: 8 },
    transition: {
      duration: 0.2,
      ease: [0.2, 0.8, 0.2, 1]
    }
  },
  scaleIn: {
    initial: { opacity: 0, scale: 0.95 },
    animate: { opacity: 1, scale: 1 },
    exit: { opacity: 0, scale: 0.95 },
    transition: {
      duration: 0.15,
      ease: [0.2, 0.8, 0.2, 1]
    }
  }
} as const;

// Layout Components
export const layoutComponents = {
  page: {
    minHeight: '100vh',
    background: tokens.colors.background,
    color: tokens.colors.text.primary,
    fontFamily: tokens.typography.fontFamily.sans.join(', ')
  },
  container: {
    maxWidth: tokens.layout.container['2xl'],
    margin: '0 auto',
    padding: `0 ${tokens.spacing[6]}`
  },
  nav: {
    height: '64px',
    background: 'rgba(17, 17, 17, 0.95)',
    backdropFilter: 'blur(20px)',
    borderBottom: `1px solid ${tokens.colors.stroke.soft}`,
    position: 'sticky' as const,
    top: 0,
    zIndex: tokens.zIndex.sticky
  },
  sidebar: {
    width: '280px',
    background: tokens.colors.surface[1],
    borderRight: `1px solid ${tokens.colors.stroke.soft}`,
    height: 'calc(100vh - 64px)',
    position: 'sticky' as const,
    top: '64px'
  },
  drawer: {
    width: '400px',
    background: tokens.colors.surface[1],
    borderLeft: `1px solid ${tokens.colors.stroke.soft}`,
    height: 'calc(100vh - 64px)',
    position: 'sticky' as const,
    top: '64px'
  },
  statusBar: {
    height: '32px',
    background: tokens.colors.surface[2],
    borderTop: `1px solid ${tokens.colors.stroke.soft}`,
    position: 'fixed' as const,
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: tokens.zIndex.fixed
  }
} as const;

export type ComponentVariants = {
  button: keyof typeof buttonVariants;
  card: keyof typeof cardVariants;
  input: keyof typeof inputVariants;
  tagChip: keyof typeof tagChipVariants;
};
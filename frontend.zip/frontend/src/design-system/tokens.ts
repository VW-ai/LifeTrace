/**
 * Design Tokens - Tag-Driven Visualization
 *
 * Defines the complete design system tokens following FRONTEND_UPDATE_PLAN.md
 * specifications for color, typography, spacing, motion, and accessibility.
 */

// Color Tokens
export const colors = {
  // Base Colors
  background: '#0a0a0a',
  surface: {
    1: '#111111',
    2: '#1a1a1a',
    3: '#242424'
  },
  text: {
    primary: '#ffffff',
    secondary: '#a1a1aa',
    muted: '#71717a'
  },
  stroke: {
    soft: '#262626',
    strong: '#404040'
  },

  // Semantic Colors
  accent: '#6366f1',
  success: '#22c55e',
  warning: '#f59e0b',
  danger: '#ef4444',

  // Tag Color Palette (colorblind-safe HSL hashes)
  tagPalette: [
    '#6366f1', // Blue (primary)
    '#8b5cf6', // Purple
    '#ec4899', // Pink
    '#f43f5e', // Rose
    '#ef4444', // Red
    '#f97316', // Orange
    '#f59e0b', // Amber
    '#eab308', // Yellow
    '#84cc16', // Lime
    '#22c55e', // Green
    '#10b981', // Emerald
    '#14b8a6', // Teal
    '#06b6d4', // Cyan
    '#0ea5e9', // Sky
    '#3b82f6', // Blue
    '#6366f1'  // Indigo (cycle back)
  ],

  // Density Ramps (perceptual sequential)
  density: {
    low: '#1e1b4b',
    medium: '#3730a3',
    high: '#6366f1',
    highest: '#a5b4fc'
  },

  // Compare Mode (diverging palette)
  compare: {
    a: '#ec4899',
    b: '#06b6d4',
    neutral: '#71717a'
  }
} as const;

// Typography Scale
export const typography = {
  fontFamily: {
    sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
    mono: ['JetBrains Mono', 'Monaco', 'Consolas', 'monospace']
  },
  fontSize: {
    xs: '12px',
    sm: '14px',
    base: '16px',
    lg: '18px',
    xl: '20px',
    '2xl': '24px',
    '3xl': '28px',
    '4xl': '36px'
  },
  fontWeight: {
    normal: '400',
    medium: '500',
    semibold: '600',
    bold: '700'
  },
  lineHeight: {
    tight: '1.25',
    normal: '1.5',
    relaxed: '1.625'
  }
} as const;

// Spacing Scale (8px base)
export const spacing = {
  0: '0px',
  1: '4px',
  2: '8px',
  3: '12px',
  4: '16px',
  5: '20px',
  6: '24px',
  8: '32px',
  10: '40px',
  12: '48px',
  16: '64px',
  20: '80px',
  24: '96px'
} as const;

// Layout & Grid
export const layout = {
  container: {
    sm: '640px',
    md: '768px',
    lg: '1024px',
    xl: '1280px',
    '2xl': '1440px'
  },
  breakpoints: {
    sm: '640px',
    md: '768px',
    lg: '1024px',
    xl: '1280px'
  }
} as const;

// Border Radius
export const radius = {
  none: '0px',
  sm: '4px',
  base: '8px',
  lg: '12px',
  xl: '16px',
  full: '9999px'
} as const;

// Elevation & Shadows
export const elevation = {
  1: '0 1px 3px rgba(0, 0, 0, 0.3)',
  2: '0 4px 12px rgba(0, 0, 0, 0.4)',
  3: '0 8px 24px rgba(0, 0, 0, 0.5)'
} as const;

// Motion & Animation
export const motion = {
  duration: {
    fast: '120ms',
    base: '200ms',
    slow: '240ms'
  },
  easing: {
    default: 'cubic-bezier(0.2, 0.8, 0.2, 1)',
    in: 'cubic-bezier(0.4, 0, 1, 1)',
    out: 'cubic-bezier(0, 0, 0.2, 1)',
    inOut: 'cubic-bezier(0.4, 0, 0.2, 1)'
  }
} as const;

// Z-Index Scale
export const zIndex = {
  dropdown: 1000,
  sticky: 1020,
  fixed: 1030,
  modal: 1040,
  popover: 1050,
  tooltip: 1060
} as const;

// Tag Color Utilities
export const getTagColor = (tag: string): string => {
  // HSL hash for stable color assignment
  let hash = 0;
  for (let i = 0; i < tag.length; i++) {
    hash = ((hash << 5) - hash + tag.charCodeAt(i)) & 0xffffffff;
  }
  const index = Math.abs(hash) % colors.tagPalette.length;
  return colors.tagPalette[index];
};

// Accessibility Helpers
export const a11y = {
  focusRing: `0 0 0 2px ${colors.accent}`,
  minTouchTarget: '44px',
  reducedMotion: '@media (prefers-reduced-motion: reduce)'
} as const;

// Export combined tokens
export const tokens = {
  colors,
  typography,
  spacing,
  layout,
  radius,
  elevation,
  motion,
  zIndex,
  a11y
} as const;

export type Tokens = typeof tokens;